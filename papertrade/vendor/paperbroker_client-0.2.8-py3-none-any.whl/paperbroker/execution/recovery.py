"""
RecoveryManager — load active orders from the persistent store and
rehydrate in-memory OrderManager state.

Split out of OrderManager (paperbroker.session.OrderManager.get_active_orders_from_store)
in v0.2.5 so that the FIX-side OrderManager only concerns itself with live
order flow. RecoveryManager wires OrderStore (data source) and OrderManager
(in-memory state) together.

Mutation of OrderManager's private state still happens inside
OrderManager.rehydrate() — RecoveryManager only orchestrates.
"""
from typing import Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from paperbroker.fix.order_manager import OrderManager
    from paperbroker.fix.order_store import OrderStore


class RecoveryManager:
    """
    Orchestrates post-restart order recovery: load + rehydrate.

    Example:
        recovery = RecoveryManager(client._order_store, client.orders)
        active = recovery.get_active_orders()
        for order in active:
            client.cancel_order(order["cl_ord_id"])
    """

    def __init__(
        self,
        order_store: Optional["OrderStore"],
        order_manager: "OrderManager",
    ):
        self._store = order_store
        self._order_manager = order_manager

    def get_active_orders(self) -> List[Dict]:
        """
        Load non-terminal orders from the store and rehydrate
        OrderManager state so cancel_order() works immediately.

        Returns the loaded rows (empty list if persistence is disabled).
        """
        if not self._store:
            return []

        rows = self._store.get_active_orders()
        self._order_manager.rehydrate(rows)
        return rows
