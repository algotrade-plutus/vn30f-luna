"""
Tick → OHLCV bar aggregation.

The BarAggregator subscribes to a market-data stream and emits ``Bar``
events on timeframe boundaries (1m, 5m, 1h, …). Alpha code consumes
``Bar`` instead of raw ticks.

Design:
    - Tick-driven: a bar closes when the first tick of the next bucket
      arrives. For market-hours-only data this matches exchange convention.
    - For tests + EOD, call ``flush()`` to force-close any pending bar.
    - Multi-instrument: a single aggregator may track multiple symbols
      independently; ``on_bar`` receives the symbol via ``bar.instrument``.

v0.2.6: pure-Python implementation. A Cython-backed variant
``paperbroker-fast`` is planned for v0.2.8.
"""
from __future__ import annotations

import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Optional


@dataclass(frozen=True)
class Bar:
    """An OHLCV bar emitted by BarAggregator."""

    instrument: str
    timestamp: datetime  # bar-close time (UTC)
    open: float
    high: float
    low: float
    close: float
    volume: float


def _parse_timeframe(spec: str) -> int:
    """
    Parse a timeframe spec into seconds.

    Accepts: ``"1m"``, ``"5m"``, ``"15m"``, ``"1h"``, ``"30s"``.
    Bare integers are interpreted as seconds.
    """
    if isinstance(spec, (int, float)):
        return int(spec)
    s = str(spec).strip().lower()
    if s.isdigit():
        return int(s)
    if s.endswith("ms"):
        # Not supported — bars below 1s aren't meaningful for tick streams.
        raise ValueError(f"Sub-second timeframes not supported: {spec!r}")
    unit = s[-1]
    qty = int(s[:-1])
    factor = {"s": 1, "m": 60, "h": 3600, "d": 86400}.get(unit)
    if factor is None:
        raise ValueError(f"Unrecognised timeframe: {spec!r}")
    return qty * factor


class BarAggregator:
    """
    Aggregate a tick stream into OHLCV bars at a fixed timeframe.

    Example:
        agg = BarAggregator("1m", on_bar=lambda b: print(b))
        await agg.attach(market_data, "HNXDS:VN30F2605")

    Test usage (synchronous):
        bars: list[Bar] = []
        agg = BarAggregator("1m", on_bar=bars.append)
        agg.on_quote("VNM", make_quote(price=100, ts=1700000000))
        agg.on_quote("VNM", make_quote(price=101, ts=1700000060))  # bucket flip
        assert bars[0].open == bars[0].close == 100  # closed first bar
    """

    def __init__(
        self,
        timeframe: str,
        on_bar: Callable[[Bar], None],
        *,
        backend: str = "python",
    ):
        if backend not in ("python", "auto"):
            raise ValueError(
                f"Unsupported backend {backend!r} (v0.2.6 ships python only)"
            )
        self.timeframe_seconds: int = _parse_timeframe(timeframe)
        self.on_bar = on_bar
        self._lock = threading.Lock()
        # instrument -> partial bar state dict
        self._current: Dict[str, Dict[str, Any]] = {}
        # Last-emitted bar per instrument, for inspection.
        self._last_bar: Dict[str, Bar] = {}
        self._instruments: set = set()
        self._market_data = None

    # -------- Public surface --------
    async def attach(self, market_data, instrument: str) -> None:
        """
        Subscribe to ``market_data`` for ``instrument``. Awaits the
        underlying subscription. Multiple instruments may be attached
        to the same aggregator.
        """
        self._instruments.add(instrument)
        self._market_data = market_data
        await market_data.subscribe(instrument, self.on_quote)

    def on_quote(self, instrument: str, quote) -> None:
        """
        Process one tick. Safe to call from any thread (e.g. the
        market_data callback thread). Idempotent for ticks with the
        same timestamp.
        """
        price = getattr(quote, "latest_matched_price", None)
        if price is None:
            return
        last_qty = getattr(quote, "latest_matched_quantity", None) or 0
        ts_raw = getattr(quote, "timestamp", None)
        if ts_raw is None:
            ts_raw = datetime.now(timezone.utc).timestamp()
        bucket = int(ts_raw // self.timeframe_seconds)

        with self._lock:
            cur = self._current.get(instrument)
            if cur is None:
                self._current[instrument] = self._new_bucket(
                    instrument, bucket, price, last_qty
                )
                return
            if bucket > cur["bucket"]:
                # Close previous bar, then start fresh
                self._emit_locked(cur)
                self._current[instrument] = self._new_bucket(
                    instrument, bucket, price, last_qty
                )
                return
            if bucket < cur["bucket"]:
                # Stale / out-of-order tick: ignore
                return
            # Same bucket — update HLCV
            cur["high"] = max(cur["high"], price)
            cur["low"] = min(cur["low"], price)
            cur["close"] = price
            cur["volume"] += last_qty

    def flush(self) -> None:
        """
        Force-emit any pending bars (e.g. at EOD, or in tests).
        After flush() the aggregator is empty until the next tick.
        """
        with self._lock:
            for cur in list(self._current.values()):
                self._emit_locked(cur)
            self._current.clear()

    def last_bar(self, instrument: str) -> Optional[Bar]:
        """Return the most recently emitted Bar for ``instrument``."""
        return self._last_bar.get(instrument)

    # -------- Internals --------
    def _new_bucket(
        self,
        instrument: str,
        bucket: int,
        price: float,
        volume: float,
    ) -> Dict[str, Any]:
        return {
            "instrument": instrument,
            "bucket": bucket,
            "open": price,
            "high": price,
            "low": price,
            "close": price,
            "volume": volume,
        }

    def _emit_locked(self, state: Dict[str, Any]) -> None:
        bar = Bar(
            instrument=state["instrument"],
            timestamp=datetime.fromtimestamp(
                (state["bucket"] + 1) * self.timeframe_seconds,
                tz=timezone.utc,
            ),
            open=state["open"],
            high=state["high"],
            low=state["low"],
            close=state["close"],
            volume=state["volume"],
        )
        self._last_bar[state["instrument"]] = bar
        try:
            self.on_bar(bar)
        except Exception:
            # Aggregator must never crash on user-callback exceptions.
            import logging
            logging.getLogger(__name__).exception(
                "BarAggregator.on_bar callback raised; swallowed."
            )
