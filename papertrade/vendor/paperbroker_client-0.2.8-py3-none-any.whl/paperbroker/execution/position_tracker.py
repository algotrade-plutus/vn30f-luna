"""
Real-time position tracking from fill events (+ optional REST reconcile).

Default mode is event-driven: each ``fix:order:filled`` /
``order:partial_fill`` event updates an in-memory position. This is
sufficient for most alphas — RealtimeRefresh is opt-in.

Reconcile loop (``start_reconcile(interval_s)``) compares the in-memory
view against the broker's REST portfolio every ``interval_s`` seconds
and logs / repairs divergences. The loop is **not spawned** until
``start_reconcile`` is called.
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional


@dataclass
class Position:
    instrument: str
    quantity: float = 0.0       # signed: long positive, short negative
    avg_price: float = 0.0      # VWAP cost basis
    last_fill_price: Optional[float] = None
    last_fill_at: Optional[Any] = None  # datetime

    def realized_at(self, mark_price: float) -> float:
        return (mark_price - self.avg_price) * self.quantity


class PositionTracker:
    """
    Track positions from fill events.

    Wiring:
        client = PaperBrokerClient(...)
        tracker = PositionTracker()
        tracker.attach(client)   # subscribes to fix:order:filled + partial_fill

    Reconcile (opt-in):
        tracker.start_reconcile(client, interval_s=60)   # spawns thread
        tracker.stop_reconcile()

    Inspection:
        pos = tracker.get("HNXDS:VN30F2605")
        all_positions = tracker.all_positions()
    """

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._positions: Dict[str, Position] = {}
        self._reconcile_thread: Optional[threading.Thread] = None
        self._reconcile_stop = threading.Event()

    # -------- Event-driven updates --------
    def attach(self, client) -> None:
        """Subscribe to ``client``'s fill events."""
        client.on("fix:order:filled", self._on_fill)
        client.on("fix:order:partial_fill", self._on_fill)

    def _on_fill(self, **payload) -> None:
        """Apply one fill event."""
        try:
            instrument = self._instrument_from_payload(payload)
            side = payload.get("side")
            last_qty = float(payload.get("last_qty", 0))
            last_px = float(payload.get("last_px", 0))
            at = payload.get("at")
        except (TypeError, ValueError):
            return
        if instrument is None or last_qty <= 0:
            return
        # Determine signed delta. If side is missing, infer from leaves
        # — but we can't always; default to BUY (+).
        sign = -1 if (side or "").upper() == "SELL" else +1
        delta = sign * last_qty
        self.update(instrument, delta, last_px, at=at)

    def update(
        self,
        instrument: str,
        delta_qty: float,
        fill_price: float,
        *,
        at: Any = None,
    ) -> Position:
        """
        Apply a manual fill (or test fill). Maintains signed quantity and
        weighted-average cost basis. Returns the updated Position.
        """
        with self._lock:
            pos = self._positions.setdefault(
                instrument, Position(instrument=instrument)
            )
            new_qty = pos.quantity + delta_qty
            # On position flip, reset cost basis to fill price.
            if pos.quantity == 0 or (pos.quantity > 0) != (new_qty > 0):
                pos.avg_price = fill_price
            elif (delta_qty > 0 and pos.quantity > 0) or (
                delta_qty < 0 and pos.quantity < 0
            ):
                # Adding to position — VWAP.
                total_cost = pos.avg_price * pos.quantity + fill_price * delta_qty
                if new_qty != 0:
                    pos.avg_price = total_cost / new_qty
            # Closing portion — avg_price unchanged.
            pos.quantity = new_qty
            pos.last_fill_price = fill_price
            pos.last_fill_at = at
            return pos

    # -------- Query --------
    def get(self, instrument: str) -> Position:
        """Return the Position for ``instrument`` (zero-position default)."""
        with self._lock:
            return self._positions.get(
                instrument, Position(instrument=instrument)
            )

    def all_positions(self) -> Dict[str, Position]:
        with self._lock:
            return {k: Position(**v.__dict__) for k, v in self._positions.items()}

    # -------- Reconcile loop --------
    def start_reconcile(
        self,
        client,
        *,
        interval_s: int = 60,
        on_drift: Optional[Callable[..., None]] = None,
    ) -> None:
        """
        Spawn a background thread that periodically queries
        ``client.accounting.get_portfolio_by_sub()`` and compares against
        in-memory state. ``on_drift(instrument, local, remote)`` is fired
        per divergent symbol; if absent, drift is only logged.
        """
        if self._reconcile_thread is not None:
            return
        self._reconcile_stop.clear()

        def _loop():
            while not self._reconcile_stop.wait(interval_s):
                try:
                    self._reconcile_once(client, on_drift)
                except Exception:
                    import logging
                    logging.getLogger(__name__).exception(
                        "PositionTracker reconcile iteration failed; continuing."
                    )

        t = threading.Thread(
            target=_loop, name="PositionTracker.reconcile", daemon=True,
        )
        self._reconcile_thread = t
        t.start()

    def stop_reconcile(self) -> None:
        if self._reconcile_thread is None:
            return
        self._reconcile_stop.set()
        self._reconcile_thread.join(timeout=2.0)
        self._reconcile_thread = None

    def _reconcile_once(
        self,
        client,
        on_drift: Optional[Callable[..., None]],
    ) -> None:
        result = client.accounting.get_portfolio_by_sub()
        items = result.get("items", []) if isinstance(result, dict) else []
        remote: Dict[str, float] = {}
        for it in items:
            inst = it.get("instrument")
            qty  = float(it.get("quantity", 0))
            if inst:
                remote[inst] = qty
        with self._lock:
            for inst, qty in remote.items():
                local = self._positions.get(inst, Position(instrument=inst)).quantity
                if abs(local - qty) > 1e-9:
                    if on_drift is not None:
                        try:
                            on_drift(instrument=inst, local=local, remote=qty)
                        except Exception:
                            pass
                    else:
                        import logging
                        logging.getLogger(__name__).warning(
                            "PositionTracker drift on %s: local=%s remote=%s",
                            inst, local, qty,
                        )

    # -------- Internals --------
    @staticmethod
    def _instrument_from_payload(payload: Dict[str, Any]) -> Optional[str]:
        # Fill payloads use cl_ord_id as primary key but we ideally need the
        # symbol. Different event variants pass it differently; try a few.
        return (
            payload.get("instrument")
            or payload.get("symbol")
            or payload.get("full_symbol")
        )
