"""
Execution primitives (v0.2.6).

Exports:
    - BarAggregator + Bar: tick → OHLCV bar aggregation
    - TradingSession: HCM exchange calendar
    - StateStore: JSON-backed K/V persistence
    - PositionTracker + Position: in-memory positions from fill events
    - RecoveryManager: load orders from OrderStore + rehydrate state

These are opt-in building blocks for alphas; importing the subpackage
does not start any threads or subscribe to anything.
"""
from .bar_aggregator import Bar, BarAggregator
from .position_tracker import Position, PositionTracker
from .recovery import RecoveryManager
from .state_store import StateStore
from .trading_session import TradingSession

__all__ = [
    "Bar",
    "BarAggregator",
    "Position",
    "PositionTracker",
    "RecoveryManager",
    "StateStore",
    "TradingSession",
]
