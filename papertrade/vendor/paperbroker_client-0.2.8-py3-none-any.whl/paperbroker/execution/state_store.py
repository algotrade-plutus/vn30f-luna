"""
JSON-backed key-value persistence for alpha state.

Alpha code that needs to survive restarts (e.g. last fired signal, EMA
buffers, running PnL counters) calls ``store.set("key", value)`` —
the value must be JSON-serialisable. Subsequent ``store.get("key")``
calls return the value, even across processes.

The store also offers an opt-in subscription:
    store.watch("key", on_change_cb)

The runtime (alpha framework) is responsible for emitting changes —
this class only registers watchers and dispatches.

Persistence:
    - Writes are debounced: every ``store.set`` updates the in-memory
      view and schedules a save on the next ``flush()`` (or process exit).
    - To make writes immediate, call ``store.flush()``.
    - All writes are atomic: write to ``<path>.tmp`` then ``os.replace``.
"""
from __future__ import annotations

import atexit
import json
import os
import threading
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional


class StateStore:
    """
    Thread-safe JSON-backed K/V store.

    Example:
        store = StateStore("alpha_state.json")
        store.set("last_fill_px", 92.5)
        ...
        # After process restart:
        last = store.get("last_fill_px")  # → 92.5

    Notes:
        - Values must be JSON-serialisable (dict, list, str, int, float,
          bool, None). Decimal / datetime need to be coerced explicitly.
        - ``watch()`` only fires when ``set()`` is called — direct file
          edits aren't observed.
    """

    def __init__(self, path: str, *, autoflush: bool = True):
        self.path = Path(path)
        self._lock = threading.RLock()
        self._data: Dict[str, Any] = {}
        self._dirty: bool = False
        self._watchers: Dict[str, List[Callable[..., None]]] = {}
        if self.path.exists():
            try:
                with self.path.open("r", encoding="utf-8") as fh:
                    self._data = json.load(fh) or {}
            except Exception:
                import logging
                logging.getLogger(__name__).warning(
                    "StateStore could not parse %s; starting empty.",
                    self.path,
                )
                self._data = {}
        if autoflush:
            atexit.register(self.flush)

    # -------- Public surface --------
    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        with self._lock:
            old = self._data.get(key)
            self._data[key] = value
            if old != value:
                self._dirty = True
                self._notify(key, old, value)

    def delete(self, key: str) -> None:
        with self._lock:
            if key in self._data:
                old = self._data.pop(key)
                self._dirty = True
                self._notify(key, old, None)

    def keys(self) -> List[str]:
        with self._lock:
            return list(self._data.keys())

    def watch(
        self,
        key: str,
        on_change: Callable[..., None],
    ) -> None:
        """
        Register ``on_change(key, old, new)`` callback for ``key``.

        Listener fires synchronously inside ``set()`` / ``delete()``. Keep
        the callback fast; defer heavy work to another thread if needed.
        """
        with self._lock:
            self._watchers.setdefault(key, []).append(on_change)

    def unwatch(
        self,
        key: str,
        on_change: Callable[..., None],
    ) -> None:
        with self._lock:
            lst = self._watchers.get(key)
            if lst:
                try:
                    lst.remove(on_change)
                except ValueError:
                    pass

    def flush(self) -> None:
        """Persist the current view to disk (atomic write)."""
        with self._lock:
            if not self._dirty:
                return
            tmp = self.path.with_suffix(self.path.suffix + ".tmp")
            tmp.parent.mkdir(parents=True, exist_ok=True)
            with tmp.open("w", encoding="utf-8") as fh:
                json.dump(self._data, fh, indent=2, sort_keys=True)
            os.replace(tmp, self.path)
            self._dirty = False

    # -------- Internals --------
    def _notify(self, key: str, old: Any, new: Any) -> None:
        listeners = list(self._watchers.get(key, ()))
        for cb in listeners:
            try:
                cb(key=key, old=old, new=new)
            except Exception:
                import logging
                logging.getLogger(__name__).exception(
                    "StateStore.watch callback raised for key=%s", key,
                )
