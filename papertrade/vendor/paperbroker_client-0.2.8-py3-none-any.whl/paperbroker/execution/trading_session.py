"""
Trading-session calendar for the Vietnamese HCM exchange.

v0.2.6 ships a hard-coded HCM session:
    - Morning:    09:15 - 11:30  (Asia/Ho_Chi_Minh)
    - Lunch:      11:30 - 13:00  (closed)
    - Afternoon:  13:00 - 14:45

Weekend & VN public holidays close the market all day. A simple holiday
set is provided here; production holiday calendars should be supplied
explicitly via ``holidays=...`` (e.g. loaded from an exchange feed).

The class is timezone-aware: pass any ``datetime`` (naive datetimes are
assumed Asia/Ho_Chi_Minh local time) and it returns boolean / next-event
times in UTC.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta, timezone
from typing import Callable, Iterable, List, Optional, Set, Tuple

try:
    from zoneinfo import ZoneInfo
    _HCM_TZ = ZoneInfo("Asia/Ho_Chi_Minh")
except Exception:  # py < 3.9 or zoneinfo missing — fall back to fixed offset
    _HCM_TZ = timezone(timedelta(hours=7))


_MORNING_OPEN  = time(9, 15)
_MORNING_CLOSE = time(11, 30)
_AFT_OPEN      = time(13, 0)
_AFT_CLOSE     = time(14, 45)


@dataclass
class _Window:
    """A continuous open interval [start, end) on a given calendar date."""

    start: datetime  # local-tz aware
    end: datetime    # local-tz aware

    def contains(self, ts: datetime) -> bool:
        return self.start <= ts < self.end


@dataclass
class TradingSession:
    """
    HCM exchange session calendar.

    Args:
        holidays: Optional set/list of ``date`` objects considered closed.
                  Defaults to empty (weekends only).

    Example:
        sess = TradingSession()
        if sess.is_open(datetime.now()):
            ...
        next_close_utc = sess.next_close(datetime.now())
    """

    holidays: Set[date] = field(default_factory=set)
    _listeners: List[Callable[..., None]] = field(default_factory=list, init=False, repr=False)

    def __post_init__(self) -> None:
        self.holidays = set(self.holidays)

    # -------- Public surface --------
    def is_open(self, ts: Optional[datetime] = None) -> bool:
        """True if HCM market is currently open at ``ts`` (default: now)."""
        local = self._to_local(ts or datetime.now(tz=timezone.utc))
        return self._current_window(local) is not None

    def next_open(self, ts: Optional[datetime] = None) -> datetime:
        """Return the next session-open boundary (UTC) on or after ``ts``."""
        local = self._to_local(ts or datetime.now(tz=timezone.utc))
        # Try today's two windows first
        for w in self._day_windows(local.date()):
            if local < w.start:
                return w.start.astimezone(timezone.utc)
        # Otherwise scan forward up to 30 days
        d = local.date() + timedelta(days=1)
        for _ in range(30):
            for w in self._day_windows(d):
                return w.start.astimezone(timezone.utc)
            d += timedelta(days=1)
        raise RuntimeError("No trading day found in next 30 days")

    def next_close(self, ts: Optional[datetime] = None) -> datetime:
        """
        Return the next session-close boundary (UTC) at or after ``ts``.

        If the market is currently open, returns the close of the current
        window (morning or afternoon). If closed, returns the close of the
        next window that will open.
        """
        local = self._to_local(ts or datetime.now(tz=timezone.utc))
        cur = self._current_window(local)
        if cur is not None:
            return cur.end.astimezone(timezone.utc)
        # Find next opening window's close
        for w in self._day_windows(local.date()):
            if local < w.start:
                return w.end.astimezone(timezone.utc)
        d = local.date() + timedelta(days=1)
        for _ in range(30):
            ws = self._day_windows(d)
            if ws:
                return ws[0].end.astimezone(timezone.utc)
            d += timedelta(days=1)
        raise RuntimeError("No trading day found in next 30 days")

    def is_holiday(self, d: date) -> bool:
        return d in self.holidays

    def on_session_change(self, cb: Callable[..., None]) -> None:
        """
        Register a callback invoked when the session opens or closes.

        The runtime that drives the schedule (Alpha framework, scheduler)
        must call ``_emit_change(state)`` at the boundary — this class
        only stores the listeners.
        """
        self._listeners.append(cb)

    def _emit_change(self, state: str, ts: Optional[datetime] = None) -> None:
        """Emit a session-state change (``"open"`` / ``"close"``) to listeners."""
        ts = ts or datetime.now(tz=timezone.utc)
        for cb in list(self._listeners):
            try:
                cb(state=state, at=ts)
            except Exception:
                import logging
                logging.getLogger(__name__).exception(
                    "TradingSession listener raised; swallowed."
                )

    # -------- Internals --------
    def _to_local(self, ts: datetime) -> datetime:
        if ts.tzinfo is None:
            return ts.replace(tzinfo=_HCM_TZ)
        return ts.astimezone(_HCM_TZ)

    def _day_windows(self, d: date) -> List[_Window]:
        # Closed on weekends + listed holidays.
        if d.weekday() >= 5 or d in self.holidays:
            return []
        morning = _Window(
            start=datetime.combine(d, _MORNING_OPEN,  tzinfo=_HCM_TZ),
            end=  datetime.combine(d, _MORNING_CLOSE, tzinfo=_HCM_TZ),
        )
        afternoon = _Window(
            start=datetime.combine(d, _AFT_OPEN,  tzinfo=_HCM_TZ),
            end=  datetime.combine(d, _AFT_CLOSE, tzinfo=_HCM_TZ),
        )
        return [morning, afternoon]

    def _current_window(self, local: datetime) -> Optional[_Window]:
        for w in self._day_windows(local.date()):
            if w.contains(local):
                return w
        return None
