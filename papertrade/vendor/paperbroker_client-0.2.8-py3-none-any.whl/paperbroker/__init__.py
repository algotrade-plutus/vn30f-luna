"""
PaperBroker Client — Python client for algorithmic trading via FIX protocol.

v0.2.5 refactor:
    - PaperBrokerClient and PaperBrokerRESTClient are now the same class:
      ``PaperBrokerRESTClient`` is a shim for ``PaperBrokerClient(enable_fix=False)``.
    - Subpackages:
        paperbroker.fix       — FIX engine + order manager + order store
        paperbroker.execution — recovery (more primitives in v0.2.6)
        paperbroker.alpha     — empty placeholder (v0.2.6)
        paperbroker.risk      — empty placeholder (v0.2.6)
        paperbroker.rest      — REST account client + session

Public symbols (unchanged from v0.2.4):
    - PaperBrokerClient
    - PaperBrokerRESTClient
    - render_quickfix_cfg
    - EventBus
    - RedisMarketDataClient
    - QuoteSnapshot
    - is_quickfix_available
"""
from paperbroker.client import PaperBrokerClient
from paperbroker.events import EventBus
from paperbroker.market_data import QuoteSnapshot, RedisMarketDataClient
from paperbroker.rest_only_client import PaperBrokerRESTClient


def is_quickfix_available() -> bool:
    """Return True if QuickFIX is importable in this environment."""
    try:
        import quickfix  # noqa: F401
        return True
    except Exception:
        return False


def render_quickfix_cfg(*args, **kwargs):
    """Lazy re-export of paperbroker.config.render_quickfix_cfg.

    Kept as a callable rather than a direct re-export so ``import paperbroker``
    does not eagerly import QuickFIX (Mac arm64 compat).
    """
    from paperbroker.config import render_quickfix_cfg as _impl
    return _impl(*args, **kwargs)


__all__ = [
    "PaperBrokerClient",
    "PaperBrokerRESTClient",
    "render_quickfix_cfg",
    "EventBus",
    "RedisMarketDataClient",
    "QuoteSnapshot",
    "is_quickfix_available",
]
