"""
SignalDrivenAlpha — multi-instrument, signal-driven alpha base class (v0.2.7).

Subclass and override the 4 abstract methods:

    class MyAlpha(SignalDrivenAlpha):
        def get_indicators(self, ctx):
            sym = self.config.instruments[0]
            return {"rsi": _rsi([b.close for b in ctx.bars[sym]])}

        def get_signals(self, indicators, ctx):
            sym = self.config.instruments[0]
            rsi = indicators["rsi"]
            if rsi is None: return []
            if rsi < 30:  return [Signal(sym, "BUY")]
            if rsi > 70:  return [Signal(sym, "SELL")]
            return []

        def get_entry_price(self, signal, ctx):
            quote = ctx.quotes.get(signal.symbol)
            return quote.latest_matched_price if quote else None

        def get_quantity(self, signal, ctx):
            return self.config.qty_for(signal.symbol)

Optional override for advanced execution (iceberg, ladder, cross-asset
multi-leg, multi-account split, …):

    def plan_orders(self, signal, ctx):
        # Default 1:1 mapping. Override to return list of OrderRequests.
        ...

Exit logic (take-profit, stop-loss, EOD close, trailing) is the
subclass's responsibility — emit a close Signal from ``get_signals``
when the exit condition is met by inspecting ``ctx.positions``.

Lifecycle (sealed — do not override):
    start() → subscribe all instruments → joint trigger fires get_signals
    stop()  → unsubscribe all
"""
from __future__ import annotations

import abc
import asyncio
import dataclasses
import logging
import threading
import time
import uuid
from collections import defaultdict, deque
from datetime import datetime, timezone
from typing import (
    Any, Callable, Deque, Dict, List, Optional, Set,
)

from paperbroker.execution import BarAggregator, PositionTracker, StateStore
from .config import AlphaConfig
from .types import (
    AccountState,
    AlphaContext,
    CloseSignal,
    OrderRequest,
    OrderState,
    Signal,
    SignalState,
)


# Default TTL for AccountState cache (seconds).
_ACCOUNT_CACHE_TTL_S = 1.0


class SignalDrivenAlpha(abc.ABC):
    """
    Bar-driven multi-instrument alpha base class.

    Sealed lifecycle; subclass implements 4 abstract hooks (plus
    optional ``plan_orders`` for non-trivial execution).

    Construction:
        alpha = MyAlpha(client=client, market_data=md, config=cfg)
        await alpha.start()
        ...
        alpha.stop()

    Or via factory:
        alpha = MyAlpha.from_paper(
            instrument="HNXDS:VN30F2605", sub_account="main", qty=1,
            params={"rsi_period": 14},
        )
    """

    # ---- Logical states ----
    STATE_INIT     = "init"
    STATE_RUNNING  = "running"
    STATE_STOPPING = "stopping"
    STATE_STOPPED  = "stopped"

    # ---- Maximum bar history retained per symbol ----
    HISTORY_LIMIT = 1024

    # ---- Optional: subclass declares known param keys for typo guard ----
    # Override as a class attribute, e.g. ``declared_params = {"rsi_period"}``.
    # When set, __init__ warns on any unknown key in ``config.params``.
    # Leave as ``None`` (default) to skip the check.
    declared_params: "Optional[Set[str]]" = None

    # ---- Trigger source pluggability (v0.2.7 Milestone E) ----
    # ``trigger_on_bar``: fire hook chain on bar-close events from the
    #     ``BarAggregator``. Default True — suits signal-driven alphas
    #     (RSI, Bollinger, pair-spread, etc.) that need closed-bar OHLCV.
    # ``trigger_on_quote``: fire hook chain on quote-tick events from
    #     the market-data callback. Default False — opt-in for MM-style
    #     alphas that quote 2-sided around the mid and refresh on price
    #     drift. Subclasses typically also override
    #     ``should_evaluate_on_quote`` to throttle (e.g. skip when mid
    #     hasn't moved).
    # Both can be True simultaneously: bar-driven re-evaluate strategy
    # state, quote-driven re-quote during the bar.
    trigger_on_bar: bool = True
    trigger_on_quote: bool = False

    # ==================================================================
    # Construction
    # ==================================================================
    def __init__(
        self,
        *,
        client,
        market_data,
        config: AlphaConfig,
    ) -> None:
        self.client = client
        self.market_data = market_data
        self.config = config
        self.logger = logging.getLogger(
            f"paperbroker.alpha.{type(self).__name__}"
        )

        # Per-symbol bar history
        self.bars: Dict[str, Deque] = {
            sym: deque(maxlen=self.HISTORY_LIMIT)
            for sym in config.instruments
        }
        # Per-cl_ord_id OrderState lifecycle tracking. Source of truth.
        # Includes terminal orders briefly (until next ctx build prunes
        # them) for fill-event ordering safety.
        self._orders: Dict[str, "OrderState"] = {}
        # parent_signal_id → SignalState (orders attached by reference)
        self._signals: Dict[str, "_SignalRecord"] = {}
        # Lock for thread-safe order/signal updates from FIX event thread
        # vs hook-chain thread.
        self._tracking_lock = threading.Lock()
        # Optional per-instrument latest quote snapshot
        self._latest_quotes: Dict[str, Any] = {}

        self.state: str = self.STATE_INIT
        self._subscriptions: List[Callable[[], None]] = []
        self._aggregator: Optional[BarAggregator] = None
        self._position_tracker: Optional[PositionTracker] = None
        self._state_store: Optional[StateStore] = None

        # Account state cache
        self._account_cache: Optional[AccountState] = None
        self._account_cache_at: float = 0.0
        self._account_lock = threading.Lock()

        # Bar-window collation
        self._collation_lock = threading.Lock()
        self._collation_buffer: Set[str] = set()
        self._collation_first_bar_at: Optional[float] = None
        self._collation_timer: Optional[threading.Timer] = None

        if config.state_path:
            self._state_store = StateStore(config.state_path)

        # Optional typo guard for config.params
        declared = type(self).declared_params
        if declared is not None:
            unknown = set(config.params.keys()) - set(declared)
            if unknown:
                self.logger.warning(
                    "%s: config.params contains keys not declared in "
                    "declared_params=%s: %s. Possible typo?",
                    type(self).__name__,
                    sorted(declared),
                    sorted(unknown),
                )

    @property
    def state_store(self) -> StateStore:
        """Strict accessor: raises if ``config.state_path`` was not set.

        Use ``self.state_store`` when persistence is required;
        ``self._state_store`` if you want to opt-out gracefully when
        state is absent.
        """
        if self._state_store is None:
            raise RuntimeError(
                f"{type(self).__name__}: state_store accessed but "
                f"config.state_path is None. Either pass state_path in "
                f"AlphaConfig, or guard access via `self._state_store` "
                f"and handle the None case."
            )
        return self._state_store

    # ==================================================================
    # Abstract surface — override in subclass
    # ==================================================================
    @abc.abstractmethod
    def get_indicators(self, ctx: AlphaContext) -> Any:
        """Return any indicator state for this trigger.

        Free-form return value (dict, dataclass, tuple — whatever the
        ``get_signals`` consumer expects). Called once per trigger.
        """

    @abc.abstractmethod
    def get_signals(
        self,
        indicators: Any,
        ctx: AlphaContext,
    ) -> List[Signal]:
        """Return zero or more Signals to act on this trigger.

        Empty list = skip this trigger. For exit signals (TP, SL, EOD
        close, trailing) inspect ``ctx.positions`` and emit
        opposite-side Signals — framework does not provide built-in
        exit infrastructure.
        """

    @abc.abstractmethod
    def get_entry_price(
        self,
        signal: Signal,
        ctx: AlphaContext,
    ) -> Optional[float]:
        """Return the limit price for ``signal``.

        Return ``None`` to skip this signal (e.g. quote not available).
        Subclass typically reads ``ctx.quotes[signal.symbol]`` or the
        latest bar close from ``ctx.bars``.
        """

    @abc.abstractmethod
    def get_quantity(
        self,
        signal: Signal,
        ctx: AlphaContext,
    ) -> int:
        """Return order quantity for ``signal``.

        Default impl in most subclasses: ``self.config.qty_for(signal.symbol)``.
        Return ``0`` to skip this signal.
        """

    # ------------------------------------------------------------------
    # Optional override — tactical execution layer
    # ------------------------------------------------------------------
    def plan_orders(
        self,
        signal: Signal,
        ctx: AlphaContext,
    ) -> List[OrderRequest]:
        """Expand a Signal into one or more concrete OrderRequests.

        Default behavior depends on signal type:

        - ``Signal`` (entry): 1:1 mapping using ``get_entry_price`` +
          ``get_quantity`` hooks. Override for iceberg slicing,
          limit-price ladders, multi-leg execution, or cross-asset
          routing (signal symbol ≠ order symbol).
        - ``CloseSignal`` / ``TakeProfitSignal`` / ``StopLossSignal``
          (exit): auto-size = ``abs(ctx.positions[sym].quantity)``,
          ``ord_type="MARKET"`` (flatten fast). Override ``plan_orders``
          for non-default exits (e.g. TP via LIMIT, partial exits).

        Every returned ``OrderRequest`` is tracked individually as an
        ``OrderState``; multi-leg plans get a shared ``parent_signal_id``
        and aggregate via ``SignalState`` accessible at
        ``ctx.signals[parent_signal_id]``.
        """
        if isinstance(signal, CloseSignal):
            return self._plan_close_orders(signal, ctx)
        # Entry path: 1:1 with get_entry_price + get_quantity
        price = self.get_entry_price(signal, ctx)
        qty = self.get_quantity(signal, ctx)
        if qty is None or qty <= 0:
            return []
        return [
            OrderRequest(
                symbol=signal.symbol,
                side=signal.side,
                qty=int(qty),
                price=float(price) if price is not None else None,
                ord_type="MARKET" if price is None else "LIMIT",
                tag=signal.tag,
            )
        ]

    def _plan_close_orders(
        self,
        signal: "CloseSignal",
        ctx: AlphaContext,
    ) -> List[OrderRequest]:
        """Default close behavior: flatten current position at MARKET.

        Sizing: ``abs(ctx.positions[signal.symbol].quantity)``. Returns
        ``[]`` when there is no open position to close (no-op exit).

        Tag derivation: if ``signal.tag is None``, derive from subclass:
        ``TakeProfitSignal → "tp"``, ``StopLossSignal → "sl"``,
        ``CloseSignal → "close"``. Set ``tag=`` on the signal to override.

        Override this method (or ``plan_orders``) when you want different
        close semantics — partial exits, TP via LIMIT, scale-out ladders.
        """
        pos = ctx.positions.get(signal.symbol)
        qty = 0
        if pos is not None:
            qty = abs(int(getattr(pos, "quantity", 0)))
        if qty <= 0:
            return []
        tag = signal.tag
        if tag is None:
            tag_defaults = {
                "TakeProfitSignal": "tp",
                "StopLossSignal": "sl",
                "CloseSignal": "close",
            }
            tag = tag_defaults.get(type(signal).__name__, "close")
        return [
            OrderRequest(
                symbol=signal.symbol,
                side=signal.side,
                qty=qty,
                price=None,
                ord_type="MARKET",
                tag=tag,
            )
        ]

    # ==================================================================
    # Sealed lifecycle
    # ==================================================================
    async def start(self) -> None:
        """Subscribe to bar streams + fill events; begin consuming."""
        if self.state != self.STATE_INIT:
            raise RuntimeError(f"Cannot start in state={self.state}")

        # Position tracker — used for ctx.positions and fill bookkeeping
        self._position_tracker = PositionTracker()
        self._position_tracker.attach(self.client)

        # Bar aggregator — subscribe each configured instrument
        self._aggregator = BarAggregator(
            timeframe=self.config.timeframe,
            on_bar=self._on_bar,
        )
        for symbol in self.config.instruments:
            await self._aggregator.attach(self.market_data, symbol)
            # Wire a passthrough quote subscriber so ctx.quotes stays fresh
            await self.market_data.subscribe(symbol, self._on_quote)

        # Some market-data backends (Kafka) need an explicit consumer
        # start AFTER subscribe() registers the topics. Redis pub/sub
        # starts implicitly on subscribe — calling start() is a no-op for
        # already-running backends.
        md_start = getattr(self.market_data, "start", None)
        if md_start is not None and asyncio.iscoroutinefunction(md_start):
            await md_start()

        # Order lifecycle listener — updates OrderState/SignalState from
        # FIX events. Terminal events (filled/canceled/rejected) clear
        # the order's working slot; partial_fill only updates progress.
        update_handler = self._on_order_update
        events = (
            "fix:order:accepted",
            "fix:order:partial_fill",
            "fix:order:filled",
            "fix:order:canceled",
            "fix:order:rejected",
        )
        for ev in events:
            self.client.on(ev, update_handler)
            # Capture ev by default-arg to avoid late-binding in closure
            self._subscriptions.append(
                lambda ev=ev: self.client.off(ev, update_handler)
            )

        self.state = self.STATE_RUNNING
        self.logger.info(
            "alpha=%s state=%s instruments=%s timeframe=%s",
            type(self).__name__, self.state,
            self.config.instruments, self.config.timeframe,
        )

    def stop(self) -> None:
        """Detach subscriptions, flush state-store, stop consuming."""
        self.state = self.STATE_STOPPING
        # Cancel any pending collation timer
        with self._collation_lock:
            if self._collation_timer is not None:
                self._collation_timer.cancel()
                self._collation_timer = None
        for unsub in self._subscriptions:
            try:
                unsub()
            except Exception:
                self.logger.exception("unsubscribe raised; swallowed.")
        self._subscriptions.clear()
        if self._state_store is not None:
            try:
                self._state_store.flush()
            except Exception:
                self.logger.exception("StateStore flush raised; swallowed.")
        self.state = self.STATE_STOPPED

    def run(self) -> None:
        """Synchronous convenience entry point: blocks until ``stop()``.

        For async/event-loop integration call ``await self.start()`` and
        manage the loop externally.
        """
        import asyncio

        ev = threading.Event()
        loop = asyncio.new_event_loop()

        async def _main():
            await self.start()
            while not ev.is_set() and self.state == self.STATE_RUNNING:
                await asyncio.sleep(1.0)
            self.stop()

        self._external_stop = ev.set  # test hook
        try:
            loop.run_until_complete(_main())
        finally:
            loop.close()

    # ==================================================================
    # Factory
    # ==================================================================
    _PAPER_CLIENT_ENV_VARS = (
        "PAPER_USERNAME",
        "PAPER_PASSWORD",
        "PAPER_REST_BASE_URL",
        "SOCKET_HOST",
        "SOCKET_PORT",
        "SENDER_COMP_ID",
        "TARGET_COMP_ID",
    )
    _PAPER_MARKET_DATA_ENV_VARS = (
        "MARKET_REDIS_HOST",
        "MARKET_REDIS_PORT",
    )

    @classmethod
    def from_paper(
        cls,
        *,
        instrument: Optional[str] = None,
        instruments: Optional[List[str]] = None,
        sub_account: str,
        client=None,
        market_data=None,
        allow_defaults: bool = False,
        **config_kwargs,
    ) -> "SignalDrivenAlpha":
        """Build an instance pre-wired against the paper backend.

        Pass either ``instrument="X"`` (single-symbol shortcut) or
        ``instruments=[...]`` (explicit multi-symbol). Mutually exclusive.

        When ``client`` / ``market_data`` are omitted they are
        constructed from environment variables. By default any missing
        env var raises ``EnvironmentError`` — pass ``allow_defaults=True``
        for local dev/test (falls back to localhost).
        """
        import os

        if instrument is None and instruments is None:
            raise TypeError(
                "from_paper requires either `instrument` (single) or "
                "`instruments` (list)"
            )
        if instrument is not None and instruments is not None:
            raise TypeError(
                "from_paper accepts `instrument` OR `instruments`, not both"
            )
        if instrument is not None:
            instruments = [instrument]

        if client is None:
            cls._require_env(
                cls._PAPER_CLIENT_ENV_VARS,
                allow_defaults=allow_defaults,
                ctx="from_paper() auto-construct client",
            )
            from paperbroker import PaperBrokerClient
            client = PaperBrokerClient(
                default_sub_account=sub_account,
                username=os.getenv("PAPER_USERNAME", ""),
                password=os.getenv("PAPER_PASSWORD", ""),
                rest_base_url=os.getenv("PAPER_REST_BASE_URL", "http://localhost:9090"),
                socket_connect_host=os.getenv("SOCKET_HOST", "localhost"),
                socket_connect_port=int(os.getenv("SOCKET_PORT", "5001")),
                sender_comp_id=os.getenv("SENDER_COMP_ID", "BL-FIX"),
                target_comp_id=os.getenv("TARGET_COMP_ID", "SERVER"),
            )
            logging.getLogger(f"paperbroker.alpha.{cls.__name__}").info(
                "from_paper: client configured username=%s rest=%s fix=%s:%s "
                "sender=%s target=%s",
                os.getenv("PAPER_USERNAME", "<unset>"),
                os.getenv("PAPER_REST_BASE_URL", "<default-localhost:9090>"),
                os.getenv("SOCKET_HOST", "<default-localhost>"),
                os.getenv("SOCKET_PORT", "<default-5001>"),
                os.getenv("SENDER_COMP_ID", "<default-BL-FIX>"),
                os.getenv("TARGET_COMP_ID", "<default-SERVER>"),
            )

        if market_data is None:
            cls._require_env(
                cls._PAPER_MARKET_DATA_ENV_VARS,
                allow_defaults=allow_defaults,
                ctx="from_paper() auto-construct market_data",
            )
            from paperbroker.market_data import RedisMarketDataClient
            market_data = RedisMarketDataClient(
                host=os.getenv("MARKET_REDIS_HOST", "localhost"),
                port=int(os.getenv("MARKET_REDIS_PORT", "6379")),
                password=os.getenv("MARKET_REDIS_PASSWORD"),
                merge_updates=True,
            )
            logging.getLogger(f"paperbroker.alpha.{cls.__name__}").info(
                "from_paper: market_data configured redis=%s:%s",
                os.getenv("MARKET_REDIS_HOST", "<default-localhost>"),
                os.getenv("MARKET_REDIS_PORT", "<default-6379>"),
            )

        cfg = AlphaConfig(
            instruments=instruments,
            sub_account=sub_account,
            **config_kwargs,
        )
        return cls(client=client, market_data=market_data, config=cfg)

    @staticmethod
    def _require_env(
        var_names,
        *,
        allow_defaults: bool,
        ctx: str,
    ) -> None:
        """Raise EnvironmentError when any required env var is unset/empty."""
        if allow_defaults:
            return
        import os
        missing = [v for v in var_names if not os.getenv(v, "").strip()]
        if missing:
            raise EnvironmentError(
                f"{ctx}: missing or empty env vars: {', '.join(missing)}.\n"
                f"Set them in your .env or pass `allow_defaults=True` "
                f"(localhost fallback, intended for local dev only) or pass "
                f"`client=`/`market_data=` explicitly."
            )

    # ==================================================================
    # Quote stream — populate ctx.quotes, optionally trigger evaluation
    # ==================================================================
    def should_evaluate_on_quote(self, instrument: str, quote) -> bool:
        """Override to throttle / filter quote-driven evaluation.

        Default behavior:
        - Returns ``self.trigger_on_quote`` (False unless subclass opts in)

        When ``trigger_on_quote = True``, MM-style alphas typically
        override this to skip when the price hasn't moved:

            def should_evaluate_on_quote(self, sym, q):
                last = self._last_eval_px.get(sym)
                if last != q.latest_matched_price:
                    self._last_eval_px[sym] = q.latest_matched_price
                    return True
                return False

        Called from the market-data callback thread; must be cheap.
        """
        return self.trigger_on_quote

    def _on_quote(self, instrument: str, quote) -> None:
        """Stash the latest quote and optionally schedule a trigger.

        Quote cache always populated (used by bar-trigger ctx builds
        too). When ``should_evaluate_on_quote`` returns True, this also
        notes the instrument for collation — same debounce pipeline as
        bar triggers.

        Called from the market-data callback thread.
        """
        self._latest_quotes[instrument] = quote
        if self.state != self.STATE_RUNNING:
            return
        if instrument not in self.bars:
            return
        try:
            if self.should_evaluate_on_quote(instrument, quote):
                self._note_trigger_for_collation(instrument)
        except Exception:
            self.logger.exception(
                "should_evaluate_on_quote raised for %s; skipping trigger",
                instrument,
            )

    # ==================================================================
    # Bar pump + collation
    # ==================================================================
    def _on_bar(self, bar) -> None:
        """Receive one closed bar from the aggregator."""
        if self.state != self.STATE_RUNNING:
            return
        if bar.instrument not in self.bars:
            # Bar for an instrument we never subscribed to — defensive.
            self.logger.warning(
                "Received bar for unknown instrument %s; ignoring.",
                bar.instrument,
            )
            return
        self.bars[bar.instrument].append(bar)
        if self.trigger_on_bar:
            self._note_trigger_for_collation(bar.instrument)

    def _note_trigger_for_collation(self, symbol: str) -> None:
        """Debounce: schedule a single joint evaluation per trigger burst.

        Called by both bar arrival (``_on_bar``) and quote arrival
        (``_on_quote`` when ``should_evaluate_on_quote`` returns True).
        Same collation pipeline — within ``bar_window_ms`` triggers
        coalesce into one ``ctx`` build + hook chain run.
        """
        now = time.monotonic()
        with self._collation_lock:
            self._collation_buffer.add(symbol)
            if self._collation_first_bar_at is None:
                self._collation_first_bar_at = now

            # Compute remaining time before hard upper bound.
            elapsed_ms = (now - self._collation_first_bar_at) * 1000
            max_wait_ms = self.config.bar_max_wait_ms
            window_ms = self.config.bar_window_ms

            # If hard upper bound already hit, fire immediately.
            if elapsed_ms >= max_wait_ms:
                self._cancel_timer_locked()
                self._fire_collation_locked()
                return

            # Otherwise (re)schedule timer for the lesser of:
            #   - bar_window_ms (debounce since LAST bar)
            #   - remaining time before hard upper bound
            remaining_max_ms = max_wait_ms - elapsed_ms
            wait_ms = min(window_ms, remaining_max_ms)
            self._cancel_timer_locked()
            self._collation_timer = threading.Timer(
                wait_ms / 1000.0,
                self._collation_fire,
            )
            self._collation_timer.daemon = True
            self._collation_timer.start()

    def _cancel_timer_locked(self) -> None:
        """Cancel any pending collation timer. Caller holds collation_lock."""
        if self._collation_timer is not None:
            self._collation_timer.cancel()
            self._collation_timer = None

    def _collation_fire(self) -> None:
        """Timer thread entry: fire collation if alpha still running."""
        if self.state != self.STATE_RUNNING:
            return
        with self._collation_lock:
            self._fire_collation_locked()

    def _fire_collation_locked(self) -> None:
        """Build ctx from buffer + dispatch _evaluate."""
        triggered_by = sorted(self._collation_buffer)
        self._collation_buffer.clear()
        self._collation_first_bar_at = None
        self._collation_timer = None
        if not triggered_by:
            return
        # Release the lock before evaluating (heavy work)
        # Re-enter as plain non-locked call.
        # (We do this by computing triggered_by, then escaping the lock
        # context. Since the with-block scope is _fire_collation_locked's
        # caller, we can't strictly "release" here. But _evaluate is
        # called outside this with-block via _flush.)
        # Use a thread to avoid blocking the lock.
        threading.Thread(
            target=self._evaluate,
            args=(triggered_by,),
            name=f"alpha.{type(self).__name__}.evaluate",
            daemon=True,
        ).start()

    def _evaluate(self, triggered_by: List[str]) -> None:
        """Build AlphaContext + run the hook chain."""
        try:
            ctx = self._build_context(triggered_by)
        except Exception:
            self.logger.exception("Failed to build AlphaContext; skipping.")
            return

        try:
            indicators = self.get_indicators(ctx)
        except Exception:
            self.logger.exception(
                "get_indicators raised; skipping trigger triggered_by=%s",
                triggered_by,
            )
            return

        try:
            signals = self.get_signals(indicators, ctx)
        except Exception:
            self.logger.exception(
                "get_signals raised; skipping trigger triggered_by=%s",
                triggered_by,
            )
            return

        if not signals:
            return
        if not isinstance(signals, list):
            self.logger.error(
                "get_signals must return a list[Signal], got %s; skipping.",
                type(signals).__name__,
            )
            return

        for signal in signals:
            self._dispatch_signal(signal, ctx)

    def _dispatch_signal(self, signal: Signal, ctx: AlphaContext) -> None:
        """Expand a Signal to OrderRequests, validate, place each.

        **Policy is alpha's responsibility, not framework's.** This
        method does NOT silently dedup or block signals. If your alpha
        wants single-entry-per-symbol semantics, check
        ``ctx.open_orders.get(sym)`` in ``get_signals`` and return ``[]``
        when occupied. The framework just tracks and places.
        """
        if not isinstance(signal, Signal):
            self.logger.error(
                "get_signals returned non-Signal item: %r; skipping.", signal
            )
            return

        try:
            orders = self.plan_orders(signal, ctx)
        except Exception:
            self.logger.exception(
                "plan_orders raised for signal=%s; skipping.", signal
            )
            return

        if not orders:
            return

        parent_signal_id = uuid.uuid4().hex[:12]
        emitted_at = datetime.now(timezone.utc)
        with self._tracking_lock:
            self._signals[parent_signal_id] = _SignalRecord(
                signal_id=parent_signal_id,
                symbol=signal.symbol,
                emitted_at=emitted_at,
                order_cl_ids=[],  # populated by _place_order on success
            )
        for order in orders:
            self._place_order(
                order, signal=signal, parent_signal_id=parent_signal_id,
            )

    def _place_order(
        self,
        order: OrderRequest,
        *,
        signal: Signal,
        parent_signal_id: str,
    ) -> None:
        """Validate + send one OrderRequest. Track lifecycle via OrderState."""
        if not isinstance(order, OrderRequest):
            self.logger.error(
                "plan_orders item is not OrderRequest: %r; skipping.", order
            )
            return
        # C4 — order.symbol must be in declared instruments
        if order.symbol not in self.bars:
            self.logger.error(
                "OrderRequest.symbol=%r not in config.instruments=%s; "
                "subscribe-then-trade contract violated; skipping.",
                order.symbol, list(self.bars.keys()),
            )
            return
        if order.qty is None or order.qty <= 0:
            return

        place_kwargs = dict(
            full_symbol=order.symbol,
            side=order.side,
            qty=int(order.qty),
            ord_type=order.ord_type,
        )
        if order.price is not None:
            place_kwargs["price"] = float(order.price)
        if order.sub_account is not None:
            place_kwargs["sub_account"] = order.sub_account

        try:
            cl_ord_id = self.client.place_order(**place_kwargs)
        except Exception:
            self.logger.exception(
                "place_order raised for signal=%s order=%s; skipping.",
                signal.symbol, order,
            )
            return

        placed_at = datetime.now(timezone.utc)
        tag = order.tag or signal.tag

        self.logger.info(
            "alpha_order signal=%s side=%s qty=%s price=%s ord_type=%s "
            "tag=%s cl_ord_id=%s parent_signal_id=%s",
            order.symbol, order.side, order.qty, order.price,
            order.ord_type, tag, cl_ord_id, parent_signal_id,
        )

        # Track in _orders + _signals atomically.
        order_state = OrderState(
            cl_ord_id=cl_ord_id,
            parent_signal_id=parent_signal_id,
            symbol=order.symbol,
            side=order.side,
            ord_type=order.ord_type,
            order_qty=int(order.qty),
            price=order.price,
            placed_at=placed_at,
            status="PENDING_NEW",
            cum_qty=0,
            avg_px=None,
            tag=tag,
        )
        with self._tracking_lock:
            self._orders[cl_ord_id] = order_state
            sig_record = self._signals.get(parent_signal_id)
            if sig_record is not None:
                sig_record.order_cl_ids.append(cl_ord_id)

    def _on_order_update(self, **payload) -> None:
        """Update OrderState from any FIX order lifecycle event.

        Handles ``fix:order:accepted``, ``partial_fill``, ``filled``,
        ``canceled``, ``rejected``. Pops the order from ``_orders`` only
        on terminal status — partial_fill keeps the slot open with
        updated ``cum_qty`` / ``avg_px`` (fixes v0.2.7 RC bug where any
        fill cleared the slot).
        """
        # Cancel events reference the original order via orig_cl_ord_id;
        # other events use cl_ord_id directly.
        cl = payload.get("orig_cl_ord_id") or payload.get("cl_ord_id")
        if cl is None:
            return

        # Map FIX-side status names to OrderStatus enum.
        raw_status = str(payload.get("status", "")).upper()
        status_map = {
            "NEW": "NEW",
            "PARTIALLY_FILLED": "PARTIALLY_FILLED",
            "FILLED": "FILLED",
            "CANCELED": "CANCELED",
            "CANCELLED": "CANCELED",
            "REJECTED": "REJECTED",
            "DONE_FOR_DAY": "DONE_FOR_DAY",
            "EXPIRED": "EXPIRED",
        }
        new_status = status_map.get(raw_status)

        with self._tracking_lock:
            existing = self._orders.get(cl)
            if existing is None:
                # Untracked cl_ord_id (cancel ack for an unknown order,
                # or event arrived before _place_order finished — race).
                return

            # Pull fill progress fields if present.
            cum_qty = payload.get("cum_qty")
            avg_px_payload = payload.get("avg_px")
            last_px = payload.get("last_px")
            last_qty = payload.get("last_qty")

            # If cum_qty not provided but last_qty is (some partial-fill
            # events omit cum), fold it into existing cumulative.
            updated_cum = existing.cum_qty
            if cum_qty is not None:
                updated_cum = int(cum_qty)
            elif last_qty is not None:
                updated_cum = existing.cum_qty + int(last_qty)

            # Update VWAP. Use avg_px from payload if provided; else
            # compute from last_px + cumulative.
            updated_avg = existing.avg_px
            if avg_px_payload is not None:
                updated_avg = float(avg_px_payload)
            elif last_px is not None and last_qty is not None and updated_cum > 0:
                prior_qty = existing.cum_qty
                prior_avg = existing.avg_px or 0.0
                updated_avg = (
                    (prior_avg * prior_qty + float(last_px) * float(last_qty))
                    / updated_cum
                )

            updated = dataclasses.replace(
                existing,
                status=new_status or existing.status,
                cum_qty=updated_cum,
                avg_px=updated_avg,
            )
            self._orders[cl] = updated

            # Prune terminal orders + their entry from signal record's
            # working set. We keep the OrderState in _orders until the
            # next ctx build (so concurrent callers see the final state)
            # but mark them terminal — _build_context filters.
            # No pop here: the OrderState carries its own terminal flag
            # via .is_terminal.

    # ==================================================================
    # AlphaContext builder
    # ==================================================================
    def _build_context(self, triggered_by: List[str]) -> AlphaContext:
        positions = {}
        if self._position_tracker is not None:
            positions = self._position_tracker.all_positions()

        # Build open_orders + signals from internal tracking. Atomic
        # snapshot under the lock to avoid mid-build FIX-event mutation.
        open_orders: Dict[str, List[OrderState]] = defaultdict(list)
        signals_view: Dict[str, SignalState] = {}
        with self._tracking_lock:
            # Per-symbol working orders (non-terminal). Terminal orders
            # are exposed through SignalState.orders but pruned here so
            # alpha's `if ctx.open_orders.get(sym)` check reflects only
            # actually-in-flight state.
            for o in self._orders.values():
                if not o.is_terminal:
                    open_orders[o.symbol].append(o)
            # Sort each list by placed_at for stable iteration order.
            for orders_list in open_orders.values():
                orders_list.sort(key=lambda o: o.placed_at)
            # Per-signal aggregate: include both working AND terminal
            # legs so alpha can reason about a signal's total progress.
            for sig_id, record in self._signals.items():
                leg_states = [
                    self._orders[cl]
                    for cl in record.order_cl_ids
                    if cl in self._orders
                ]
                signals_view[sig_id] = SignalState(
                    signal_id=record.signal_id,
                    symbol=record.symbol,
                    emitted_at=record.emitted_at,
                    orders=leg_states,
                )
            # Garbage-collect fully-terminal signals + their orders to
            # keep memory bounded. Alpha sees them once (in this ctx),
            # then they're pruned. (If alpha needs longer history,
            # snapshot it into its own state_store.)
            terminal_sig_ids = [
                sid for sid, sig in signals_view.items() if sig.is_terminal
            ]
            for sid in terminal_sig_ids:
                record = self._signals.pop(sid, None)
                if record is not None:
                    for cl in record.order_cl_ids:
                        self._orders.pop(cl, None)

        return AlphaContext(
            bars=self.bars,
            quotes=dict(self._latest_quotes),
            positions=positions,
            open_orders=dict(open_orders),
            signals=signals_view,
            account=self._get_cached_account_state(),
            now=datetime.now(timezone.utc),
            triggered_by=triggered_by,
        )

    # ==================================================================
    # AccountState cache (TTL 1 s)
    # ==================================================================
    def _get_cached_account_state(self) -> AccountState:
        """Return account snapshot, refreshing if older than TTL."""
        now = time.monotonic()
        with self._account_lock:
            if (
                self._account_cache is not None
                and (now - self._account_cache_at) < _ACCOUNT_CACHE_TTL_S
            ):
                return self._account_cache
            try:
                state = self._fetch_account_state()
            except Exception:
                self.logger.exception(
                    "Failed to fetch account state; serving stale (or empty)."
                )
                state = self._account_cache or AccountState()
            self._account_cache = state
            self._account_cache_at = now
            return state

    def _fetch_account_state(self) -> AccountState:
        """Pull fresh account snapshot from broker. Defensive on missing API."""
        get_balance = getattr(self.client, "get_cash_balance", None)
        if get_balance is None:
            return AccountState()
        try:
            resp = get_balance()
        except Exception:
            raise
        if not isinstance(resp, dict):
            return AccountState()

        def _float(v):
            try:
                return float(v) if v is not None else 0.0
            except (TypeError, ValueError):
                return 0.0

        return AccountState(
            cash=_float(resp.get("remainCash") or resp.get("cash")),
            equity=_float(
                resp.get("totalBalance") or resp.get("equity") or resp.get("balance")
            ),
            margin_used=_float(resp.get("marginUsed") or resp.get("margin_used")),
            extra={
                k: v for k, v in resp.items()
                if k not in (
                    "remainCash", "cash", "totalBalance", "equity",
                    "balance", "marginUsed", "margin_used",
                )
            },
        )


# ----------------------------------------------------------------------
# Internal records
# ----------------------------------------------------------------------
class _SignalRecord:
    """Mutable mirror of SignalState used internally.

    Live state (latest ``OrderState``s) lives in ``_orders``; this
    record just remembers the parent metadata + which cl_ord_ids belong
    to this signal. ``_build_context`` projects this into a public
    ``SignalState`` snapshot for the alpha.
    """

    __slots__ = ("signal_id", "symbol", "emitted_at", "order_cl_ids")

    def __init__(
        self,
        *,
        signal_id: str,
        symbol: str,
        emitted_at: datetime,
        order_cl_ids: List[str],
    ):
        self.signal_id = signal_id
        self.symbol = symbol
        self.emitted_at = emitted_at
        self.order_cl_ids = order_cl_ids
