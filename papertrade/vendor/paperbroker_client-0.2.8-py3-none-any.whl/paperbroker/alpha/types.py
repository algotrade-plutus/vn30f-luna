"""
Value objects for the v0.2.7 alpha framework.

Immutable value objects + context container passed between alpha hooks:

- ``Signal``             — strategic intent emitted by ``get_signals``
- ``CloseSignal``        — subtype: exit intent (auto-sized + MARKET by default)
- ``TakeProfitSignal``   — subtype of CloseSignal, attribution-only
- ``StopLossSignal``     — subtype of CloseSignal, attribution-only
- ``OrderRequest``       — tactical execution unit emitted by ``plan_orders``
- ``OrderState``         — live state of one in-flight or settled order
- ``SignalState``        — aggregated state across all orders from one signal
- ``AccountState``       — snapshot of cash / equity / margin at trigger time
- ``AlphaContext``       — per-trigger bundle delivered to every hook

**Mechanism vs policy (v0.2.7 Milestone E):** the framework owns state
tracking (``OrderState`` / ``SignalState``) and trigger plumbing; the
alpha owns policy (when to emit, what to emit). The framework does NOT
silently dedup or block signals — if you want "one entry at a time per
symbol", check ``ctx.open_orders.get(sym)`` in your ``get_signals``
hook and return ``[]`` when occupied.

Exit semantics (TP/SL/OCO/EOD) are explicitly NOT baked in — they live
in the subclass's ``get_signals`` hook. The ``CloseSignal`` /
``TakeProfitSignal`` / ``StopLossSignal`` subtypes carry semantic intent
for attribution + framework defaults (auto-size to current position,
MARKET ord_type) but never override alpha behaviour silently.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Deque, Dict, List, Literal, Optional


Side = Literal["BUY", "SELL"]
OrdType = Literal["LIMIT", "MARKET"]


@dataclass(frozen=True)
class Signal:
    """
    Strategic intent emitted by ``get_signals``.

    A Signal expresses "I want to trade ``symbol`` in direction ``side``".
    The framework expands each Signal into one or more ``OrderRequest``
    via ``plan_orders`` (default impl: 1:1).

    Attributes:
        symbol:   Instrument to trade. Must be in ``config.instruments``
                  (validated at order-place time).
        side:     ``"BUY"`` or ``"SELL"``.
        tag:      Optional attribution tag (e.g. ``"entry"``, ``"tp"``,
                  ``"sl"``, ``"eod"``, ``"rebalance"``). Propagates to
                  the OrderRequest for observability/grouping. Subtypes
                  (``CloseSignal`` etc.) auto-derive a default tag from
                  the class name when ``tag is None``.
        metadata: Free-form per-signal dict (e.g. z-score, indicator
                  values at signal time). Not interpreted by framework.
    """
    symbol: str
    side: Side
    tag: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class CloseSignal(Signal):
    """
    Exit intent — "close (part of) the open position on ``symbol``".

    Framework defaults (when alpha doesn't override ``get_quantity`` /
    ``plan_orders``):

    - ``get_quantity`` returns ``abs(ctx.positions[symbol].quantity)``
      — flatten current exposure
    - ``plan_orders`` uses ``ord_type="MARKET"`` (price=None) — exit fast

    Override the relevant hook in your alpha if you want different
    behaviour (e.g. exit half via LIMIT at TP price).

    The ``side`` you specify is the order side, NOT the position side:
    to close a LONG, emit ``CloseSignal(side="SELL", ...)``.
    """


@dataclass(frozen=True)
class TakeProfitSignal(CloseSignal):
    """
    Attribution-only subtype of ``CloseSignal``. Same defaults
    (auto-size, MARKET). Use when your alpha wants downstream logs /
    metrics to distinguish TP exits from generic closes / SL exits.
    """


@dataclass(frozen=True)
class StopLossSignal(CloseSignal):
    """
    Attribution-only subtype of ``CloseSignal``. Same defaults
    (auto-size, MARKET). Use when your alpha wants downstream logs /
    metrics to distinguish SL exits from TP / generic closes.
    """


@dataclass(frozen=True)
class OrderRequest:
    """
    Tactical execution unit emitted by ``plan_orders``.

    One OrderRequest = one order sent to the broker. ``plan_orders`` may
    return multiple OrderRequests per Signal (iceberg, ladder, multi-leg)
    or have ``symbol`` differ from ``Signal.symbol`` (cross-asset
    execution where signal-instrument and trade-instrument are decoupled).

    Attributes:
        symbol:           Instrument to send the order on. Must be in
                          ``config.instruments``.
        side:             ``"BUY"`` or ``"SELL"``.
        qty:              Strict positive int.
        price:            Limit price; pass ``None`` for MARKET orders.
        ord_type:         ``"LIMIT"`` (default) or ``"MARKET"``.
        sub_account:      Override default sub-account; ``None`` = use
                          ``config.sub_account``.
        tag:              Inherits ``signal.tag`` by default. Override
                          per-leg if needed (e.g. ``"slice_0"``).
        parent_signal_id: Auto-assigned by framework. Groups all
                          OrderRequests originating from one Signal.
    """
    symbol: str
    side: Side
    qty: int
    price: Optional[float] = None
    ord_type: OrdType = "LIMIT"
    sub_account: Optional[str] = None
    tag: Optional[str] = None
    parent_signal_id: Optional[str] = None


OrderStatus = Literal[
    "PENDING_NEW",
    "NEW",
    "PARTIALLY_FILLED",
    "FILLED",
    "CANCELED",
    "REJECTED",
    "PENDING_CANCEL",
    "DONE_FOR_DAY",
    "EXPIRED",
]

_TERMINAL_STATUSES = frozenset(
    {"FILLED", "CANCELED", "REJECTED", "DONE_FOR_DAY", "EXPIRED"}
)


@dataclass(frozen=True)
class OrderState:
    """
    Live state of one order. Built by the framework when an order is
    placed; updated from FIX events (accepted / partial_fill / filled /
    canceled / rejected). Exposed read-only to alpha via
    ``ctx.open_orders[symbol]``.

    Replaces the bare ``cl_ord_id`` strings the v0.2.7 RC framework
    tracked in ``open_entries[symbol]: list[str]``. Alpha now sees full
    lifecycle: size, fill progress, average fill price, terminal status.

    Attributes:
        cl_ord_id:        Client order ID assigned by ``OrderManager``.
        parent_signal_id: Groups all orders fanned out from one Signal.
        symbol:           Instrument the order trades.
        side:             ``"BUY"`` or ``"SELL"``.
        ord_type:         ``"LIMIT"`` or ``"MARKET"``.
        order_qty:        Submitted quantity.
        price:            Limit price (``None`` for MARKET).
        placed_at:        UTC timestamp when ``place_order`` returned.
        status:           Latest known status. See ``OrderStatus`` enum.
        cum_qty:          Cumulative filled quantity (0 until first fill).
        avg_px:           Volume-weighted average fill price across
                          partial fills (``None`` until first fill).
        tag:              Inherited from ``OrderRequest.tag`` /
                          ``Signal.tag`` for attribution.
    """
    cl_ord_id: str
    parent_signal_id: str
    symbol: str
    side: Side
    ord_type: OrdType
    order_qty: int
    price: Optional[float]
    placed_at: datetime
    status: OrderStatus = "PENDING_NEW"
    cum_qty: int = 0
    avg_px: Optional[float] = None
    tag: Optional[str] = None

    @property
    def remaining_qty(self) -> int:
        """Order qty still working at the venue (or 0 if terminal)."""
        return max(0, self.order_qty - self.cum_qty)

    @property
    def is_terminal(self) -> bool:
        """True once the order can no longer fill (FILLED/CANCELED/...)."""
        return self.status in _TERMINAL_STATUSES

    @property
    def is_working(self) -> bool:
        """True while the order can still produce fills (NEW / PARTIALLY_FILLED)."""
        return self.status in ("NEW", "PARTIALLY_FILLED", "PENDING_NEW")


@dataclass(frozen=True)
class SignalState:
    """
    Aggregated state across all ``OrderState``s fanned out from one
    Signal via ``plan_orders``. Useful for alphas that emit multi-leg
    intents (iceberg, cross-asset, atomic pair) and want to reason
    about the parent signal's progress as a unit.

    Built by the framework on every ``ctx`` build; alpha sees it via
    ``ctx.signals[parent_signal_id]``.

    Attributes:
        signal_id:  ``parent_signal_id`` shared by all legs.
        symbol:     Symbol of the originating Signal (NOT necessarily
                    the OrderRequest symbols — cross-asset routes orders
                    elsewhere). Read leg-specific symbols from
                    ``orders[i].symbol``.
        emitted_at: UTC timestamp when the parent Signal was dispatched.
        orders:     Snapshot of all OrderState legs at ``ctx`` build time.
    """
    signal_id: str
    symbol: str
    emitted_at: datetime
    orders: List["OrderState"]

    @property
    def total_ordered_qty(self) -> int:
        """Sum of ``order_qty`` across every leg."""
        return sum(o.order_qty for o in self.orders)

    @property
    def total_filled_qty(self) -> int:
        """Sum of ``cum_qty`` across every leg."""
        return sum(o.cum_qty for o in self.orders)

    @property
    def remaining_qty(self) -> int:
        """Qty still working across all non-terminal legs."""
        return sum(o.remaining_qty for o in self.orders if not o.is_terminal)

    @property
    def avg_fill_px(self) -> Optional[float]:
        """Qty-weighted average fill price across legs, or None if no fills."""
        filled = [(o.cum_qty, o.avg_px) for o in self.orders
                  if o.cum_qty > 0 and o.avg_px is not None]
        if not filled:
            return None
        total_qty = sum(q for q, _ in filled)
        if total_qty == 0:
            return None
        return sum(q * px for q, px in filled) / total_qty

    @property
    def is_terminal(self) -> bool:
        """True once every leg has settled (filled/canceled/rejected/...)."""
        return all(o.is_terminal for o in self.orders) if self.orders else False


@dataclass(frozen=True)
class AccountState:
    """
    Snapshot of account financials at the moment a trigger fires.

    Built lazily by the framework with a 1-second TTL cache (so multiple
    hooks within one evaluation see the same numbers without spamming
    the REST endpoint). Extra broker-specific fields land in ``extra``.

    Attributes:
        cash:        Liquid cash balance (VND or quote currency).
        equity:      Total equity = cash + position MTM.
        margin_used: Initial margin currently committed.
        extra:       Backend-specific overflow (e.g. ``intraday_pnl``,
                     ``margin_call_status``). Don't depend in cross-
                     backend code.
    """
    cash: float = 0.0
    equity: float = 0.0
    margin_used: float = 0.0
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AlphaContext:
    """
    Per-trigger bundle passed to every hook.

    Mutable container (the framework writes into it once per trigger,
    hooks read). Hooks should NOT mutate it — the framework does not
    enforce this but doing so leaks state across hooks unpredictably.

    Attributes:
        bars:         Per-symbol rolling history of closed Bars.
        quotes:       Latest-quote snapshot per symbol (may be stale by
                      up to one tick — pulled at trigger build time).
        positions:    Current position snapshot per symbol (signed qty +
                      VWAP, via ``PositionTracker``).
        open_orders:  Per-symbol list of in-flight + recently-settled
                      ``OrderState`` instances. Replaces the v0.2.7 RC
                      ``open_entries: Dict[str, List[str]]`` (bare cl_ord_ids).
                      Alpha inspects this for concurrency policy:
                      ``if ctx.open_orders.get(sym): return []`` for
                      single-entry alphas.
        signals:      ``parent_signal_id`` → ``SignalState`` map.
                      Aggregates ``OrderState`` legs from one Signal.
                      Useful for multi-leg pattern alphas (iceberg,
                      cross-asset, pair) that need to reason about a
                      Signal's progress as a unit.
        account:      Account state snapshot (cached, TTL 1s).
        now:          Trigger fire time (UTC datetime).
        triggered_by: Symbols whose bar/quote arrival caused this
                      trigger to fire (1-N elements). Useful for alphas
                      that only re-compute indicators for the symbol(s)
                      that just changed.
    """
    bars: Dict[str, "Deque[Any]"]
    quotes: Dict[str, Any]
    positions: Dict[str, Any]
    open_orders: Dict[str, List["OrderState"]]
    signals: Dict[str, "SignalState"]
    account: AccountState
    now: datetime
    triggered_by: List[str]
