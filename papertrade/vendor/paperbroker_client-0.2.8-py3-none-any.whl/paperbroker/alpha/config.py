"""
AlphaConfig — declarative parameters for an alpha instance.

v0.2.7 schema: multi-instrument first-class. ``instruments: list[str]``
replaces the v0.2.6 ``instrument: str`` field. Single-instrument alphas
can use the ``AlphaConfig.single(symbol=...)`` factory for terseness.

All fields are validated at construct time via ``__post_init__`` —
empty strings, zero/negative qty, or wrong types raise ``ValueError``
immediately rather than failing later in the bar pump or at order
placement.

Exit logic (take-profit, stop-loss, EOD close) lives in the alpha's own
``get_signals`` hook, not in this config.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union


QtySpec = Union[int, Dict[str, int]]


@dataclass(frozen=True)
class AlphaConfig:
    """
    Parameters that drive a single alpha instance.

    Attributes:
        instruments:      Non-empty list of full symbols, e.g.
                          ``["HNXDS:VN30F2605"]`` or
                          ``["VN30F1M", "VN30F2M"]`` for pair-trade.
        sub_account:      Sub-account ID for this alpha's orders. Non-empty.
        timeframe:        Bar timeframe (``"1m"`` / ``"5m"`` / ``"1h"`` …).
        qty:              Default order quantity. ``int`` = same qty for
                          every symbol; ``dict[symbol, int]`` for
                          per-symbol sizing. Every value must be ``> 0``.
        params:           Free-form indicator parameters (must be dict).
        state_path:       Optional JSON path for StateStore persistence.
                          ``None`` = no persistence. Empty string rejected.
        log_dir:          Logging directory.
        bar_window_ms:    Debounce window for bar-window collation. When
                          a bar arrives, the framework waits up to this
                          long for other instruments' bars before firing
                          the joint evaluation. Default 500 ms.
        bar_max_wait_ms:  Hard upper bound on collation wait. After this
                          long since the first bar in the current window,
                          fire evaluation regardless of how many
                          instruments are missing. Default 5000 ms (5 s).

    Raises:
        ValueError: On any malformed field.
    """

    instruments: List[str]
    sub_account: str
    timeframe: str = "1m"
    qty: QtySpec = 1
    params: Dict[str, Any] = field(default_factory=dict)
    state_path: Optional[str] = None
    log_dir: str = "logs"
    bar_window_ms: int = 500
    bar_max_wait_ms: int = 5000

    # ------------------------------------------------------------------
    # Convenience factories
    # ------------------------------------------------------------------
    @classmethod
    def single(
        cls,
        *,
        instrument: str,
        sub_account: str,
        **kwargs: Any,
    ) -> "AlphaConfig":
        """Shortcut for single-instrument alphas (most common case).

        Equivalent to ``AlphaConfig(instruments=[instrument], ...)``.
        """
        return cls(instruments=[instrument], sub_account=sub_account, **kwargs)

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------
    def __post_init__(self) -> None:
        # instruments — non-empty list of non-empty strings
        if not isinstance(self.instruments, list):
            raise ValueError(
                f"AlphaConfig.instruments must be a list of strings, "
                f"got {type(self.instruments).__name__}"
            )
        if not self.instruments:
            raise ValueError(
                "AlphaConfig.instruments must be a non-empty list"
            )
        for i, sym in enumerate(self.instruments):
            if not isinstance(sym, str) or not sym.strip():
                raise ValueError(
                    f"AlphaConfig.instruments[{i}] must be a non-empty string, "
                    f"got {sym!r}"
                )
        if len(set(self.instruments)) != len(self.instruments):
            raise ValueError(
                f"AlphaConfig.instruments must not contain duplicates: "
                f"{self.instruments}"
            )

        # sub_account — non-empty
        if not isinstance(self.sub_account, str) or not self.sub_account.strip():
            raise ValueError(
                f"AlphaConfig.sub_account must be a non-empty string, "
                f"got {self.sub_account!r}"
            )

        # timeframe — non-empty (deep parse is BarAggregator's job)
        if not isinstance(self.timeframe, str) or not self.timeframe.strip():
            raise ValueError(
                f"AlphaConfig.timeframe must be a non-empty string like "
                f"'1m' / '5m' / '1h', got {self.timeframe!r}"
            )

        # qty — scalar positive int OR dict[symbol → positive int]
        self._validate_qty()

        # params — dict
        if not isinstance(self.params, dict):
            raise ValueError(
                f"AlphaConfig.params must be a dict, "
                f"got {type(self.params).__name__}"
            )

        # state_path — None or non-empty string
        if self.state_path is not None:
            if not isinstance(self.state_path, str) or not self.state_path.strip():
                raise ValueError(
                    f"AlphaConfig.state_path must be None or a non-empty "
                    f"path, got {self.state_path!r}"
                )

        # bar window timings — positive ints
        for name in ("bar_window_ms", "bar_max_wait_ms"):
            v = getattr(self, name)
            if isinstance(v, bool) or not isinstance(v, int) or v <= 0:
                raise ValueError(
                    f"AlphaConfig.{name} must be a positive int, got {v!r}"
                )
        if self.bar_max_wait_ms < self.bar_window_ms:
            raise ValueError(
                f"AlphaConfig.bar_max_wait_ms ({self.bar_max_wait_ms}) must "
                f"be >= bar_window_ms ({self.bar_window_ms})"
            )

    def _validate_qty(self) -> None:
        q = self.qty
        if isinstance(q, dict):
            if not q:
                raise ValueError(
                    "AlphaConfig.qty dict must be non-empty"
                )
            unknown = set(q.keys()) - set(self.instruments)
            if unknown:
                raise ValueError(
                    f"AlphaConfig.qty dict references unknown symbols "
                    f"(not in instruments): {sorted(unknown)}"
                )
            for sym, v in q.items():
                if isinstance(v, bool) or not isinstance(v, int):
                    raise ValueError(
                        f"AlphaConfig.qty[{sym!r}] must be a positive int, "
                        f"got {type(v).__name__}: {v!r}"
                    )
                if v <= 0:
                    raise ValueError(
                        f"AlphaConfig.qty[{sym!r}] must be > 0, got {v}"
                    )
            return
        if isinstance(q, bool) or not isinstance(q, int):
            raise ValueError(
                f"AlphaConfig.qty must be a positive int or dict[str,int], "
                f"got {type(q).__name__}: {q!r}"
            )
        if q <= 0:
            raise ValueError(f"AlphaConfig.qty must be > 0, got {q}")

    # ------------------------------------------------------------------
    # Convenience accessors
    # ------------------------------------------------------------------
    def qty_for(self, symbol: str) -> int:
        """Resolve per-symbol qty. Returns 0 for unknown symbols (and
        also unknown keys in dict form)."""
        if isinstance(self.qty, dict):
            return int(self.qty.get(symbol, 0))
        return int(self.qty)
