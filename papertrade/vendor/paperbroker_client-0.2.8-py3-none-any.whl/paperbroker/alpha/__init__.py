"""
Alpha framework (v0.2.7).

Subclass ``SignalDrivenAlpha`` and override 4 methods to ship an alpha:

    class MyAlpha(SignalDrivenAlpha):
        def get_indicators(self, ctx): ...
        def get_signals(self, indicators, ctx) -> list[Signal]: ...
        def get_entry_price(self, signal, ctx) -> float | None: ...
        def get_quantity(self, signal, ctx) -> int: ...

Optional override for advanced execution (iceberg, ladder, cross-asset):

        def plan_orders(self, signal, ctx) -> list[OrderRequest]: ...

Exit logic (TP, SL, EOD close) is the subclass's responsibility — emit
``CloseSignal`` / ``TakeProfitSignal`` / ``StopLossSignal`` from
``get_signals`` when the exit condition triggers (or a plain ``Signal``
on the opposite side). The framework does not bake in TP/SL/OCO
infrastructure.

State the alpha sees via ``ctx``:
- ``ctx.open_orders[sym]`` → list of ``OrderState`` (in-flight + recent)
- ``ctx.signals[parent_signal_id]`` → ``SignalState`` (aggregated legs)
- ``ctx.positions[sym]`` → ``Position`` (signed qty + VWAP)
- ``ctx.account`` → ``AccountState`` (cash/equity/margin)

See ``examples/09_alpha_rsi_1m.py`` for a worked single-instrument example
and ``examples/12_alpha_pair_spread.py`` for multi-instrument pair-trade.
"""
from .config import AlphaConfig
from .signal_driven import SignalDrivenAlpha
from .types import (
    AccountState,
    AlphaContext,
    CloseSignal,
    OrderRequest,
    OrderState,
    Signal,
    SignalState,
    StopLossSignal,
    TakeProfitSignal,
)

__all__ = [
    "AccountState",
    "AlphaConfig",
    "AlphaContext",
    "CloseSignal",
    "OrderRequest",
    "OrderState",
    "Signal",
    "SignalDrivenAlpha",
    "SignalState",
    "StopLossSignal",
    "TakeProfitSignal",
]
