"""Deprecation shim — FIXApp logic was merged into paperbroker.fix.engine.FIXEngine in v0.2.5."""
import warnings

warnings.warn(
    "paperbroker.session.app.FIXApp is deprecated; "
    "use paperbroker.fix.engine.FIXEngine (FIXApp + FIXSessionManager + 3 handlers "
    "are merged into a single class in v0.2.5). "
    "This shim will be removed in v0.3.0.",
    DeprecationWarning,
    stacklevel=2,
)

from paperbroker.fix.engine import FIXEngine  # noqa: F401,E402

# Old name preserved
FIXApp = FIXEngine

__all__ = ["FIXApp", "FIXEngine"]
