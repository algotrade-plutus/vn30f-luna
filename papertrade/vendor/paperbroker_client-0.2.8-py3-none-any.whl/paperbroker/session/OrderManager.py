"""Deprecation shim — moved to paperbroker.fix.order_manager in v0.2.5."""
import warnings

warnings.warn(
    "paperbroker.session.OrderManager is deprecated; "
    "use paperbroker.fix.order_manager (moved in v0.2.5). "
    "This shim will be removed in v0.3.0.",
    DeprecationWarning,
    stacklevel=2,
)

from paperbroker.fix.order_manager import OrderManager  # noqa: F401,E402

__all__ = ["OrderManager"]
