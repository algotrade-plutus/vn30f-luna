"""Deprecation shim — AdminHandler was inlined into paperbroker.fix.engine.FIXEngine in v0.2.5.

There is no longer a standalone class — the credential-injection logic lives
in ``FIXEngine._inject_admin_credentials``. This module re-exports the engine
so legacy imports do not break at import time.
"""
import warnings

warnings.warn(
    "paperbroker.session.handler_admin.AdminHandler is deprecated and no longer "
    "exists as a standalone class. Its logic is now FIXEngine._inject_admin_credentials. "
    "This shim will be removed in v0.3.0.",
    DeprecationWarning,
    stacklevel=2,
)

from paperbroker.fix.engine import FIXEngine  # noqa: F401,E402

# No back-compat AdminHandler class — code using it would have been internal.
__all__: list = []
