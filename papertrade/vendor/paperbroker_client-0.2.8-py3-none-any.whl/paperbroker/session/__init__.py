"""
Deprecation shim — ``paperbroker.session`` was renamed to ``paperbroker.fix`` in v0.2.5.

Importing from ``paperbroker.session.*`` continues to work but will emit
a DeprecationWarning. The shim will be removed in v0.3.0.

Update imports:

    from paperbroker.session.OrderManager      import OrderManager
    from paperbroker.session.session_manager   import FIXSessionManager
    from paperbroker.session.order_store       import OrderStore

becomes:

    from paperbroker.fix.order_manager import OrderManager
    from paperbroker.fix.engine        import FIXEngine   # FIXSessionManager alias kept
    from paperbroker.fix.order_store   import OrderStore
"""
import warnings

warnings.warn(
    "paperbroker.session is deprecated; use paperbroker.fix (renamed in v0.2.5). "
    "This shim will be removed in v0.3.0.",
    DeprecationWarning,
    stacklevel=2,
)

from paperbroker.fix.engine import FIXEngine as FIXSessionManager  # noqa: F401,E402
from paperbroker.fix.engine import FIXEngine  # noqa: F401,E402
from paperbroker.fix.order_manager import OrderManager  # noqa: F401,E402
from paperbroker.fix.order_store import OrderStore  # noqa: F401,E402

__all__ = ["FIXSessionManager", "FIXEngine", "OrderManager", "OrderStore"]
