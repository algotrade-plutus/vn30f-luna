"""Deprecation shim — moved to paperbroker.fix.engine in v0.2.5."""
import warnings

warnings.warn(
    "paperbroker.session.session_manager.FIXSessionManager is deprecated; "
    "use paperbroker.fix.engine.FIXEngine (renamed in v0.2.5). "
    "This shim will be removed in v0.3.0.",
    DeprecationWarning,
    stacklevel=2,
)

from paperbroker.fix.engine import FIXEngine  # noqa: F401,E402

# Old name preserved for back-compat
FIXSessionManager = FIXEngine

__all__ = ["FIXSessionManager", "FIXEngine"]
