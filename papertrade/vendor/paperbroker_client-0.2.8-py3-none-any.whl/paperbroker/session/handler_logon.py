"""Deprecation shim — LogonHandler was inlined into paperbroker.fix.engine.FIXEngine in v0.2.5."""
import warnings

warnings.warn(
    "paperbroker.session.handler_logon.LogonHandler is deprecated and no longer "
    "exists as a standalone class. Its logging lives directly in FIXEngine. "
    "This shim will be removed in v0.3.0.",
    DeprecationWarning,
    stacklevel=2,
)

from paperbroker.fix.engine import FIXEngine  # noqa: F401,E402

__all__: list = []
