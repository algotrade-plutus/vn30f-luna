"""Deprecation shim — moved to paperbroker.fix.order_store in v0.2.5."""
import warnings

warnings.warn(
    "paperbroker.session.order_store is deprecated; "
    "use paperbroker.fix.order_store (moved in v0.2.5). "
    "This shim will be removed in v0.3.0.",
    DeprecationWarning,
    stacklevel=2,
)

from paperbroker.fix.order_store import OrderStore  # noqa: F401,E402

__all__ = ["OrderStore"]
