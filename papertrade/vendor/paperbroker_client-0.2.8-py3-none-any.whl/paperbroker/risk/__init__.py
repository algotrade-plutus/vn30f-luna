"""
Risk plugins (v0.2.6).

Exports:
    - KillSwitch: equity-floor circuit breaker (inline emergency-flatten)

All plugins are opt-in: instantiating them does nothing until ``.start()``
is called.

Removed post-v0.2.6:
    - ``EODFlatten`` — replaced by in-signal close logic in alpha's
      ``get_signals`` hook
    - ``OCOBracket`` / TP / SL infrastructure — exit logic belongs in
      the alpha's signal hook, not framework infrastructure
"""
from .kill_switch import KillSwitch

__all__ = [
    "KillSwitch",
]
