"""
Equity-floor kill switch.

Opt-in safety plugin: when account equity drops below ``equity_floor``,
KillSwitch can either halt the alpha (action="halt") or halt + flatten
all positions (``"halt_and_flatten"``).

Usage:
    ks = KillSwitch(
        client=client,
        position_tracker=tracker,
        equity_floor=300_000_000,
        action="halt_and_flatten",
        on_trigger=lambda **kw: logger.error("KILL: %s", kw),
    )
    ks.start(check_interval_s=10)
    ...
    ks.stop()
"""
from __future__ import annotations

import threading
from typing import Any, Callable, Optional


class KillSwitch:
    """
    Watch equity periodically; trip on threshold breach.

    Args:
        client: PaperBrokerClient exposing ``get_account_balance``.
        position_tracker: optional; required if action == "halt_and_flatten".
        equity_floor: account equity (in VND) below which to trigger.
        action: ``"halt"`` (just stop trading; alpha decides what to do
                via on_trigger callback) or ``"halt_and_flatten"``.
        on_trigger: optional ``cb(equity, reason)`` invoked exactly once
                    when threshold breached.
    """

    ACTION_HALT = "halt"
    ACTION_HALT_AND_FLATTEN = "halt_and_flatten"

    def __init__(
        self,
        *,
        client,
        position_tracker=None,
        equity_floor: float,
        action: str = "halt",
        on_trigger: Optional[Callable[..., None]] = None,
    ) -> None:
        if action not in (self.ACTION_HALT, self.ACTION_HALT_AND_FLATTEN):
            raise ValueError(f"Unsupported action: {action}")
        if action == self.ACTION_HALT_AND_FLATTEN and position_tracker is None:
            raise ValueError(
                "halt_and_flatten requires position_tracker"
            )
        self.client = client
        self.position_tracker = position_tracker
        self.equity_floor = float(equity_floor)
        self.action = action
        self.on_trigger = on_trigger
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._triggered = threading.Event()

    # -------- Public --------
    def start(self, *, check_interval_s: float = 10.0) -> None:
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, args=(check_interval_s,),
            name="KillSwitch", daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None

    @property
    def triggered(self) -> bool:
        return self._triggered.is_set()

    def check_once(self) -> bool:
        """Run one balance check synchronously. Returns True if tripped."""
        if self._triggered.is_set():
            return True
        equity = self._read_equity()
        if equity is None:
            return False
        if equity < self.equity_floor:
            self._fire(equity, reason="equity_below_floor")
            return True
        return False

    # -------- Internals --------
    def _read_equity(self) -> Optional[float]:
        try:
            resp = self.client.get_account_balance()
        except Exception:
            return None
        if not isinstance(resp, dict):
            return None
        for k in ("totalBalance", "total", "balance"):
            v = resp.get(k)
            if v is not None:
                try:
                    return float(v)
                except (TypeError, ValueError):
                    continue
        return None

    def _fire(self, equity: float, reason: str) -> None:
        if self._triggered.is_set():
            return
        self._triggered.set()
        if self.on_trigger is not None:
            try:
                self.on_trigger(equity=equity, reason=reason)
            except Exception:
                import logging
                logging.getLogger(__name__).exception(
                    "KillSwitch.on_trigger callback raised; swallowed."
                )
        if self.action == self.ACTION_HALT_AND_FLATTEN:
            self._flatten_all_positions()

    def _flatten_all_positions(self) -> None:
        """Emergency liquidation: market-out every non-zero position."""
        import logging
        try:
            positions = self.position_tracker.all_positions()
        except Exception:
            logging.getLogger(__name__).exception(
                "KillSwitch: failed to read positions for flatten."
            )
            return
        for inst, pos in positions.items():
            if abs(pos.quantity) < 1e-9:
                continue
            side = "SELL" if pos.quantity > 0 else "BUY"
            qty = int(abs(pos.quantity))
            try:
                # MARKET order — safety override; price slippage acceptable
                # vs carrying exposure past the floor breach.
                self.client.place_order(
                    full_symbol=inst, side=side, qty=qty,
                    price=None, ord_type="MARKET",
                )
            except Exception:
                logging.getLogger(__name__).exception(
                    "KillSwitch: failed to flatten %s", inst,
                )

    def _loop(self, interval_s: float) -> None:
        while not self._stop.is_set():
            try:
                if self.check_once():
                    # After tripping, keep the thread alive so stop() can join,
                    # but don't re-trigger.
                    pass
            except Exception:
                import logging
                logging.getLogger(__name__).exception("KillSwitch check failed")
            self._stop.wait(interval_s)
