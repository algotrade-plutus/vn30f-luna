"""
CLI entry point for paperbroker (v0.2.6).

Wired through ``pyproject.toml [project.scripts]``:

    paperbroker run --config alpha.yaml

The YAML loader and CLI are part of the optional ``cli`` extras:

    pip install 'paperbroker-client[cli]'

YAML schema (v0.2.7 multi-instrument):
    alpha:
      class: my_pkg.MyAlpha               # importable module:Class path
      instruments: ["HNXDS:VN30F2605"]    # or list of symbols
      sub_account: main
      timeframe: 1m
      qty: 1                              # int or per-symbol dict
      params:
        rsi_period: 14
      state_path: state/my_alpha.json

Single-instrument shortcut:
    alpha:
      class: my_pkg.MyAlpha
      instrument: HNXDS:VN30F2605          # plural also accepted
      sub_account: main
"""
from __future__ import annotations

import argparse
import importlib
import logging
import sys
from typing import Any, Dict


def _load_yaml(path: str) -> Dict[str, Any]:
    try:
        import yaml  # type: ignore
    except ImportError as e:
        raise SystemExit(
            "PyYAML is required for CLI config. "
            "Install with: pip install 'paperbroker-client[cli]'"
        ) from e
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def _import_class(spec: str):
    """Resolve ``module:Class`` or ``/path/to/file.py:Class`` to a class.

    Supports digit-prefixed example file names (e.g.
    ``examples/09_alpha_rsi_1m.py:RSI1MAlpha``) that cannot be imported
    via ``importlib.import_module`` because Python module names can't
    start with a digit.
    """
    if ":" not in spec:
        # Pure dotted form: ``my_pkg.module.Class``
        module_name, cls_name = spec.rsplit(".", 1)
        mod = importlib.import_module(module_name)
        return getattr(mod, cls_name)
    module_part, cls_name = spec.split(":", 1)
    if module_part.endswith(".py") or "/" in module_part:
        # File-path form
        import os
        import importlib.util as _import_util
        file_path = os.path.abspath(module_part)
        if not os.path.exists(file_path):
            raise SystemExit(f"alpha.class file not found: {file_path}")
        # Synthesise a safe module name (digits allowed in attribute path,
        # not in module name).
        stem = os.path.splitext(os.path.basename(file_path))[0]
        mod_name = "paperbroker_alpha_user_" + "".join(
            c if c.isalnum() else "_" for c in stem
        )
        spec_obj = _import_util.spec_from_file_location(mod_name, file_path)
        if spec_obj is None or spec_obj.loader is None:
            raise SystemExit(f"Cannot load module from {file_path}")
        mod = _import_util.module_from_spec(spec_obj)
        spec_obj.loader.exec_module(mod)
        return getattr(mod, cls_name)
    # Dotted module-with-colon form: ``my_pkg.module:Class``
    mod = importlib.import_module(module_part)
    return getattr(mod, cls_name)


def run_yaml(path: str) -> None:
    """Instantiate the alpha from YAML and run() it to completion."""
    spec = _load_yaml(path)
    alpha_spec = dict(spec.get("alpha", {}))
    if not alpha_spec:
        raise SystemExit(f"{path}: missing top-level 'alpha:' block")
    cls_path = alpha_spec.pop("class", None)
    if cls_path is None:
        raise SystemExit(f"{path}: alpha.class is required")
    AlphaCls = _import_class(cls_path)
    alpha = AlphaCls.from_paper(**alpha_spec)
    alpha.run()


def diagnose() -> int:
    """Print resolved environment + quickfix availability for support."""
    from paperbroker import is_quickfix_available, __name__ as pkg_name
    import os
    import sys as _sys

    print(f"paperbroker module: {pkg_name}")
    print(f"python: {_sys.version}")
    print(f"quickfix available: {is_quickfix_available()}")
    print("env vars (FIX / REST):")
    for k in (
        "PAPER_USERNAME", "PAPER_REST_BASE_URL",
        "SOCKET_HOST", "SOCKET_PORT",
        "SENDER_COMP_ID", "TARGET_COMP_ID",
        "MARKET_REDIS_HOST", "MARKET_REDIS_PORT",
    ):
        val = os.environ.get(k)
        masked = "<unset>" if not val else (
            "<set>" if "PASSWORD" in k else val
        )
        print(f"  {k}={masked}")
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="paperbroker")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_run = sub.add_parser("run", help="Run an alpha from a YAML config")
    p_run.add_argument("--config", required=True, help="Path to YAML config")

    sub.add_parser("diagnose", help="Print environment + library info")

    args = parser.parse_args(argv)
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s] [%(levelname)s] %(name)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    if args.cmd == "run":
        run_yaml(args.config)
        return 0
    if args.cmd == "diagnose":
        return diagnose()
    parser.error(f"unknown command: {args.cmd}")
    return 2


if __name__ == "__main__":
    sys.exit(main())
