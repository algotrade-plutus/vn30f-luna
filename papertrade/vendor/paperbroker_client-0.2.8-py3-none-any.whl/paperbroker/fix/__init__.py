"""
FIX protocol subpackage (renamed from paperbroker.session in v0.2.5).

Public surface:
    - FIXEngine: lifecycle manager (was FIXSessionManager + FIXApp + 3 handlers)
    - OrderManager: order placement/cancel/state (core only; recovery in paperbroker.execution)
    - OrderStore: SQLite persistence

Old imports via paperbroker.session.* still work via deprecation shim.
"""
from .engine import FIXEngine
from .order_manager import OrderManager
from .order_store import OrderStore

# Back-compat alias — code that imported FIXSessionManager keeps working.
FIXSessionManager = FIXEngine

__all__ = [
    "FIXEngine",
    "FIXSessionManager",
    "OrderManager",
    "OrderStore",
]
