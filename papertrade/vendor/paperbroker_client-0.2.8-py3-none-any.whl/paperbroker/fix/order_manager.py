"""
Order lifecycle management — core (place / cancel / state).

Renamed and slimmed from paperbroker.session.OrderManager in v0.2.5:
recovery (`get_active_orders_from_store`) moved to
paperbroker.execution.recovery.RecoveryManager.

Public state maps (order_info, status_map, order_id_map, clord_map) and
their locks remain on OrderManager because they are mutated by the FIX
callback path (`on_execution_report`). RecoveryManager mutates them via
`rehydrate()` only.
"""
from datetime import datetime, timezone
import re
import uuid
import threading
import logging
from typing import Callable, Optional, Iterable, Dict, List
from concurrent.futures import Future, TimeoutError as FutureTimeoutError

import quickfix as fix
import quickfix44 as fix44

from .order_store import OrderStore


class OrderManager:
    """
    Thread-safe order manager with event-driven state tracking.

    Manages the complete lifecycle of orders from submission through fills
    or cancels. Uses futures for non-blocking waits and emits events for
    all state changes.
    """

    def __init__(
        self,
        logger: logging.Logger,
        emit: Optional[Callable[..., None]] = None,
        store: Optional[OrderStore] = None,
    ):
        self.logger = logger
        self.session_id: Optional[fix.SessionID] = None

        self._store: Optional[OrderStore] = store

        # State maps (protected by _state_lock)
        self._state_lock = threading.RLock()
        self.clord_map: Dict[str, str] = {}      # OrderID -> ClOrdID
        self.order_info: Dict[str, dict] = {}    # ClOrdID -> metadata
        self.status_map: Dict[str, dict] = {}    # ClOrdID -> status info
        self.order_id_map: Dict[str, str] = {}   # ClOrdID -> OrderID

        # Cancel bookkeeping (protected by _state_lock), v0.2.8:
        #   _cancel_seq        ClOrdID -> attempts so far (unique cancel IDs)
        #   _cancel_clord_map  cancel ClOrdID -> original ClOrdID
        #   _pre_cancel_status ClOrdID -> status before the optimistic
        #                      PendingCancel, restored if the cancel is rejected
        #   _cancel_rejects    ClOrdID -> last OrderCancelReject detail
        self._cancel_seq: Dict[str, int] = {}
        self._cancel_clord_map: Dict[str, str] = {}
        self._pre_cancel_status: Dict[str, str] = {}
        self._cancel_rejects: Dict[str, dict] = {}

        #: Send an OrderStatusRequest (35=H) automatically when a cancel is
        #: rejected, so a client/server disagreement self-heals. Set False to
        #: keep the wire quiet and reconcile manually.
        self.auto_status_request_on_cancel_reject: bool = True

        # Futures (protected by _futures_lock)
        self._futures_lock = threading.Lock()
        self._order_id_futures: Dict[str, Future] = {}
        self._status_events: Dict[str, threading.Event] = {}

        self._emit: Callable[..., None] = emit or (lambda *a, **k: None)

    def set_session(self, session_id: fix.SessionID) -> None:
        self.session_id = session_id
        self.logger.info(f"Order manager session set: {session_id}")

    def generate_ord_id(self) -> str:
        return str(uuid.uuid4())[:8]

    def extract_exchange_and_symbol(self, full_symbol: str) -> tuple:
        if ":" not in full_symbol:
            raise ValueError(
                f"Invalid symbol format: {full_symbol}, "
                f"expected EXCHANGE:SYMBOL"
            )
        exchange, symbol = full_symbol.split(":", 1)
        return exchange, symbol

    # ---------- Public waits ----------
    def wait_for(
        self,
        cl_ord_id: str,
        statuses: Iterable[str],
        timeout: Optional[float] = None,
    ) -> bool:
        with self._futures_lock:
            ev = self._status_events.setdefault(
                cl_ord_id, threading.Event()
            )

        with self._state_lock:
            cur = self.status_map.get(cl_ord_id, {}).get("status")
            if cur in set(statuses):
                return True

        return ev.wait(timeout=timeout)

    def wait_for_order_id(
        self,
        cl_ord_id: str,
        timeout: Optional[float] = None,
    ) -> Optional[str]:
        with self._futures_lock:
            with self._state_lock:
                if cl_ord_id in self.order_id_map:
                    return self.order_id_map[cl_ord_id]

            if cl_ord_id not in self._order_id_futures:
                self._order_id_futures[cl_ord_id] = Future()

            future = self._order_id_futures[cl_ord_id]

        try:
            return future.result(timeout=timeout)
        except FutureTimeoutError:
            self.logger.warning(
                f"Timeout waiting for OrderID for {cl_ord_id}"
            )
            return None

    # ---------- Place / Cancel ----------
    # Map TIF string → quickfix constant.
    # DAY is the default because Vietnam derivatives (HNXDS) and equities
    # (HSX/HNX) are session-day only — GTC is rejected by the broker with
    # "outside allowed same-day trading session" / "GTC_UNSUPPORTED_DAY_ONLY".
    _TIF_MAP = {
        "DAY": fix.TimeInForce_DAY,
        "GTC": fix.TimeInForce_GOOD_TILL_CANCEL,
        "IOC": fix.TimeInForce_IMMEDIATE_OR_CANCEL,
        "FOK": fix.TimeInForce_FILL_OR_KILL,
    }

    def place_order(
        self,
        full_symbol: str,
        side: str,
        qty: int,
        price: float,
        ord_type: str = "LIMIT",
        tif: str = "DAY",
    ) -> str:
        if not self.session_id:
            raise RuntimeError("FIX session is not established.")

        try:
            tif_value = self._TIF_MAP[tif.upper()]
        except KeyError as exc:
            raise ValueError(
                f"Unsupported tif={tif!r}; expected one of "
                f"{sorted(self._TIF_MAP)}"
            ) from exc

        exchange, symbol = self.extract_exchange_and_symbol(full_symbol)
        cl_ord_id = self.generate_ord_id()
        side = side.upper()

        order = fix44.NewOrderSingle()
        order.setField(fix.ClOrdID(cl_ord_id))
        order.setField(fix.Symbol(symbol))
        order.setField(fix.SecurityExchange(exchange))
        order.setField(
            fix.Side(fix.Side_BUY if side == "BUY" else fix.Side_SELL)
        )
        order.setField(fix.OrderQty(qty))
        order.setField(fix.Price(price))
        order.setField(
            fix.OrdType(
                fix.OrdType_LIMIT if ord_type == "LIMIT"
                else fix.OrdType_MARKET
            )
        )
        order.setField(fix.TimeInForce(tif_value))
        order.setField(fix.TransactTime())

        sent = fix.Session.sendToTarget(order, self.session_id)
        now = datetime.now(timezone.utc)

        if sent:
            self.logger.info(f"[ORDER] Sent new order: {cl_ord_id}")
        else:
            self.logger.error(
                f"[ORDER] Failed to send order {cl_ord_id}"
            )

        with self._state_lock:
            self.order_info[cl_ord_id] = {
                "symbol": symbol,
                "side": side,
                "qty": qty,
                "exchange": exchange,
                "price": price,
            }
            self.status_map[cl_ord_id] = {
                "status": "PendingNew",
                "time": now,
                # Optimistic, stamped with our clock — must not out-rank a
                # server report whose TransactTime is behind ours.
                "local_time": True,
            }

        with self._futures_lock:
            self._status_events.setdefault(
                cl_ord_id, threading.Event()
            ).clear()

        if self._store:
            self._store.persist_order(
                cl_ord_id=cl_ord_id,
                info={**self.order_info[cl_ord_id], "ord_type": ord_type},
                status="PendingNew",
            )

        self._emit(
            "order:submit",
            cl_ord_id=cl_ord_id,
            info=self.order_info[cl_ord_id],
            sent=bool(sent),
            at=now,
        )

        return cl_ord_id

    #: Statuses considered terminal — order is settled, no further action expected.
    TERMINAL_STATUSES = frozenset({
        "Filled", "Canceled", "Rejected", "Expired", "DoneForDay",
        # FIX-name uppercase variants that map_status() emits for some exec_types
        "FILLED", "CANCELED", "REJECTED", "EXPIRED", "DONE_FOR_DAY",
    })

    def _send_cancel(self, cl_ord_id: str, timeout: float) -> tuple:
        """
        Build and send an OrderCancelRequest (35=F).

        Shared by ``cancel_order`` and ``cancel_order_v1``. Returns
        ``(cancel_cl_ord_id, sent, now)``. Does not touch status.

        Each attempt gets its own ClOrdID (``<orig>-CXL<n>``) — FIX requires
        initiator ClOrdIDs to be unique within a session, so a retry that
        reused a fixed ``-CXL`` id was a duplicate and could be rejected or
        silently deduped by the counterparty.
        """
        order_id = self.wait_for_order_id(cl_ord_id, timeout=timeout)
        if order_id is None:
            raise TimeoutError(
                f"Timeout waiting for OrderID for {cl_ord_id}"
            )

        if not self.session_id:
            raise RuntimeError("FIX session is not established.")

        with self._state_lock:
            info = self.order_info.get(cl_ord_id)
            if not info:
                raise KeyError(f"Order {cl_ord_id} not found")
            attempt = self._cancel_seq.get(cl_ord_id, 0) + 1
            self._cancel_seq[cl_ord_id] = attempt
            cancel_cl_ord_id = f"{cl_ord_id}-CXL{attempt}"
            self._cancel_clord_map[cancel_cl_ord_id] = cl_ord_id
            # Remember what to fall back to if the server rejects this cancel.
            # Captured before the send, so a fast server PendingCancel report
            # cannot overwrite the state we would need to restore.
            current = (self.status_map.get(cl_ord_id) or {}).get("status")
            if current and current != "PendingCancel":
                self._pre_cancel_status[cl_ord_id] = current

        cancel = fix44.OrderCancelRequest()
        cancel.setField(fix.OrigClOrdID(cl_ord_id))
        cancel.setField(fix.ClOrdID(cancel_cl_ord_id))
        cancel.setField(fix.OrderID(order_id))
        cancel.setField(fix.Symbol(info["symbol"]))
        cancel.setField(fix.SecurityExchange(info.get("exchange", "")))
        cancel.setField(
            fix.Side(
                fix.Side_BUY if info["side"] == "BUY"
                else fix.Side_SELL
            )
        )
        cancel.setField(fix.OrderQty(info["qty"]))
        cancel.setField(fix.TransactTime())

        sent = fix.Session.sendToTarget(cancel, self.session_id)
        now = datetime.now(timezone.utc)

        if sent:
            self.logger.debug(
                f"[ORDER] Sent cancel request: {cancel_cl_ord_id}"
            )
        else:
            self.logger.error(
                f"[ORDER] Failed to send cancel for {cl_ord_id} "
                f"({cancel_cl_ord_id})"
            )

        return cancel_cl_ord_id, sent, now

    def cancel_order(
        self,
        cl_ord_id: str,
        timeout: float = 2.0,
    ) -> "tuple[bool, str]":
        """
        Send cancel request and wait for server response.

        v0.2.6 signature change: returns ``(is_terminal, status)`` tuple
        instead of None. ``is_terminal=True`` means the server confirmed
        a terminal state (Canceled/Filled/Rejected); ``False`` means the
        order remained in PendingCancel (timeout) or the cancel itself
        was rejected by the server.

        Old None-returning callers should migrate; the legacy behavior is
        preserved by ``cancel_order_v1`` shim (DeprecationWarning, removed
        in v0.3.0).

        If the server answers with an OrderCancelReject (35=9) the order's
        status is rolled back (the cancel did *not* take effect), so the
        returned status is the live order state — not a permanent
        ``PendingCancel``. Use ``get_last_cancel_reject(cl_ord_id)`` to see
        whether a reject happened and why.
        """
        cancel_cl_ord_id, sent, now = self._send_cancel(cl_ord_id, timeout)

        # Reset wait gate so the upcoming server response wakes us, not
        # the PendingCancel marker we are about to set.
        with self._futures_lock:
            ev = self._status_events.setdefault(
                cl_ord_id, threading.Event()
            )
            ev.clear()

        self._update_status(
            cl_ord_id, "PendingCancel", now, local_time=True
        )

        self._emit(
            "order:cancel_submit",
            cl_ord_id=cl_ord_id,
            cancel_cl_ord_id=cancel_cl_ord_id,
            at=now,
            sent=bool(sent),
        )

        # Wait for the server-confirmed terminal status (or cancel-reject
        # wake) up to ``timeout`` seconds. Returning quickly with
        # is_terminal=False is OK — caller can re-check or retry.
        self.wait_for(cl_ord_id, self.TERMINAL_STATUSES, timeout=timeout)
        final_status = self.get_order_status(cl_ord_id)
        return (final_status in self.TERMINAL_STATUSES, final_status)

    def cancel_order_v1(
        self,
        cl_ord_id: str,
        timeout: float = 2.0,
    ) -> None:
        """
        Legacy fire-and-forget cancel (pre-v0.2.6 behavior).

        Sends the cancel and returns immediately without waiting for the
        server response. New callers should use ``cancel_order`` and
        consume the ``(is_terminal, status)`` tuple. This shim will be
        removed in v0.3.0.
        """
        import warnings
        warnings.warn(
            "OrderManager.cancel_order_v1 is deprecated; use "
            "cancel_order which now returns (is_terminal, status). "
            "Removed in v0.3.0.",
            DeprecationWarning,
            stacklevel=2,
        )
        # Pre-v0.2.6 behavior = send + mark PendingCancel, no terminal wait.
        cancel_cl_ord_id, sent, now = self._send_cancel(cl_ord_id, timeout)
        self._update_status(
            cl_ord_id, "PendingCancel", now, local_time=True
        )
        self._emit(
            "order:cancel_submit",
            cl_ord_id=cl_ord_id,
            cancel_cl_ord_id=cancel_cl_ord_id,
            at=now,
            sent=bool(sent),
        )

    # ---------- Reconciliation ----------
    def request_order_status(self, cl_ord_id: str) -> bool:
        """
        Send an OrderStatusRequest (35=H) for ``cl_ord_id`` (v0.2.8).

        The server answers with an ExecutionReport (ExecType=I) carrying the
        authoritative OrdStatus, which flows through the normal
        ``on_execution_report`` path and updates local state. Use this when
        client and server disagree — e.g. after a cancel reject that claims
        the order is unknown, or after a reconnect.

        Returns True if the request was handed to the FIX session.
        """
        if not self.session_id:
            raise RuntimeError("FIX session is not established.")

        with self._state_lock:
            info = self.order_info.get(cl_ord_id)
            order_id = self.order_id_map.get(cl_ord_id)
        if not info:
            raise KeyError(f"Order {cl_ord_id} not found")

        req = fix44.OrderStatusRequest()
        req.setField(fix.ClOrdID(cl_ord_id))
        if order_id:
            req.setField(fix.OrderID(order_id))
        req.setField(fix.Symbol(info["symbol"]))
        req.setField(fix.SecurityExchange(info.get("exchange", "")))
        req.setField(
            fix.Side(
                fix.Side_BUY if info["side"] == "BUY"
                else fix.Side_SELL
            )
        )

        sent = fix.Session.sendToTarget(req, self.session_id)
        if sent:
            self.logger.info(
                f"[STATUS_REQUEST] Asked server for state of {cl_ord_id} "
                f"(orderID={order_id})"
            )
        else:
            self.logger.error(
                f"[STATUS_REQUEST] Failed to send for {cl_ord_id}"
            )
        self._emit(
            "order:status_request",
            cl_ord_id=cl_ord_id,
            order_id=order_id,
            sent=bool(sent),
            at=datetime.now(timezone.utc),
        )
        return bool(sent)

    # ---------- ExecReport / OCR handling ----------
    #: Wire status names (map_status output) → facade names used in status_map.
    _FACADE_STATUS = {
        "NEW": "New",
        "PARTIALLY_FILLED": "PartiallyFilled",
        "FILLED": "Filled",
        "CANCELED": "Canceled",
        "PENDING_CANCEL": "PendingCancel",
        "PENDING_NEW": "PendingNew",
        "REJECTED": "Rejected",
        "EXPIRED": "Expired",
        "DONE_FOR_DAY": "DoneForDay",
        "REPLACED": "Replaced",
        "SUSPENDED": "Suspended",
        "CALCULATED": "Calculated",
    }

    _CXL_SUFFIX_RE = re.compile(r"^(?P<orig>.+)-CXL\d*$")

    def _resolve_orig_cl_ord_id(self, message, fallback_clord: str) -> str:
        """
        Find the original order's ClOrdID for a cancel-shaped message.

        Prefers OrigClOrdID(41) from the wire, then the cancel-ID map built
        when we sent the cancel, then a suffix strip (covers rehydrated state
        and the pre-v0.2.8 fixed ``-CXL`` id).
        """
        try:
            tag = fix.OrigClOrdID().getTag()
            if message.isSetField(tag):
                orig = message.getField(tag)
                if orig:
                    return orig
        except Exception:  # pragma: no cover - defensive, malformed message
            pass

        with self._state_lock:
            mapped = self._cancel_clord_map.get(fallback_clord)
        if mapped:
            return mapped

        m = self._CXL_SUFFIX_RE.match(fallback_clord)
        return m.group("orig") if m else fallback_clord

    def on_business_reject(self, message) -> None:
        """
        Log a BusinessMessageReject (35=j) — e.g. an OrderStatusRequest the
        server refused. Without this the request just vanishes.
        """
        try:
            ref_id = (
                message.getField(fix.BusinessRejectRefID().getTag())
                if message.isSetField(fix.BusinessRejectRefID().getTag())
                else "?"
            )
            reason = (
                message.getField(fix.BusinessRejectReason().getTag())
                if message.isSetField(fix.BusinessRejectReason().getTag())
                else "?"
            )
            text = (
                message.getField(fix.Text().getTag())
                if message.isSetField(fix.Text().getTag())
                else "No reason"
            )
            self.logger.warning(
                f"[BUSINESS_REJECT] refID={ref_id} reason={reason}: {text}"
            )
            self._emit(
                "order:business_reject",
                ref_id=ref_id,
                code=reason,
                reason=text,
                at=datetime.now(timezone.utc),
            )
        except Exception as e:
            self.logger.error(
                f"Failed to process business message reject: {e}",
                exc_info=True,
            )

    def on_execution_report(self, message) -> None:
        try:
            msg_type = message.getHeader().getField(fix.MsgType().getTag())

            if msg_type == fix.MsgType_OrderCancelReject:
                clx = message.getField(fix.ClOrdID().getTag())
                ord_id = (
                    message.getField(fix.OrderID().getTag())
                    if message.isSetField(fix.OrderID().getTag())
                    else "?"
                )
                text = (
                    message.getField(fix.Text().getTag())
                    if message.isSetField(fix.Text().getTag())
                    else "Unknown reason"
                )
                rej_reason = (
                    message.getField(fix.CxlRejReason().getTag())
                    if message.isSetField(fix.CxlRejReason().getTag())
                    else "?"
                )
                self.logger.warning(
                    f"[CANCEL_REJECTED] Cancel for {clx} "
                    f"(orderID={ord_id}) rejected ({rej_reason}): {text}"
                )
                orig_cl_ord_id = self._resolve_orig_cl_ord_id(message, clx)
                now = datetime.now(timezone.utc)

                # A reject means the cancel did NOT take effect. Roll the
                # optimistic PendingCancel back, else the order is stuck in a
                # non-terminal state nothing can ever clear. Prefer the
                # server's own OrdStatus(39) when the reject carries it.
                restored: Optional[str] = None
                ord_status_tag = fix.OrdStatus().getTag()
                if message.isSetField(ord_status_tag):
                    wire = self.map_status(message.getField(ord_status_tag))
                    restored = self._FACADE_STATUS.get(wire, wire)
                    # 39=6 just repeats "pending cancel" — useless for rollback.
                    if restored == "PendingCancel":
                        restored = None
                if restored is None:
                    with self._state_lock:
                        restored = self._pre_cancel_status.get(orig_cl_ord_id)

                with self._state_lock:
                    self._cancel_rejects[orig_cl_ord_id] = {
                        "code": rej_reason,
                        "reason": text,
                        "at": now,
                        "cancel_cl_ord_id": clx,
                    }

                if restored is not None:
                    self._update_status(
                        orig_cl_ord_id, restored, now,
                        text=text, local_time=True,
                    )
                    self.logger.info(
                        f"[CANCEL_REJECTED] {orig_cl_ord_id} status resolved "
                        f"to {restored} (cancel did not take effect)"
                    )
                else:
                    # Nothing to restore to — record the reason and let the
                    # status request below settle it.
                    with self._state_lock:
                        entry = self.status_map.get(orig_cl_ord_id)
                        if entry is not None:
                            entry["text"] = text
                    self.logger.warning(
                        f"[CANCEL_REJECTED] No pre-cancel status known for "
                        f"{orig_cl_ord_id}; reconciling with server"
                    )

                # Wake any thread blocked in cancel_order's terminal-wait —
                # the wait then re-reads the (still-non-terminal) status
                # and returns (False, status).
                with self._futures_lock:
                    ev = self._status_events.setdefault(
                        orig_cl_ord_id, threading.Event()
                    )
                    ev.set()
                self._emit(
                    "order:cancel_reject",
                    cl_ord_id=clx,
                    orig_cl_ord_id=orig_cl_ord_id,
                    order_id=ord_id,
                    reason=text,
                    code=rej_reason,
                    status=self.get_order_status(orig_cl_ord_id),
                )

                # Ask the server what it actually thinks the order is — unless
                # the reject already settled it terminally. The answer
                # (ExecType=I) lands on the normal path above.
                if (
                    self.auto_status_request_on_cancel_reject
                    and not self.is_order_done(orig_cl_ord_id)
                ):
                    try:
                        self.request_order_status(orig_cl_ord_id)
                    except Exception as e:
                        self.logger.warning(
                            f"[STATUS_REQUEST] Could not reconcile "
                            f"{orig_cl_ord_id}: {e}"
                        )
                return

            if msg_type != fix.MsgType_ExecutionReport:
                return

            cl_ord_id = message.getField(fix.ClOrdID().getTag())
            ord_status = message.getField(fix.OrdStatus().getTag())
            exec_type = message.getField(fix.ExecType().getTag())
            ord_id = message.getField(fix.OrderID().getTag())
            transact_time_str = message.getField(fix.TransactTime().getTag())
            transact_time = datetime.strptime(
                transact_time_str, "%Y%m%d-%H:%M:%S.%f"
            ).replace(tzinfo=timezone.utc)

            with self._state_lock:
                self.order_id_map[cl_ord_id] = ord_id
                if ord_id:
                    self.clord_map[ord_id] = cl_ord_id

            if self._store and ord_id:
                self._store.update_order_id(cl_ord_id, ord_id)

            with self._futures_lock:
                if cl_ord_id in self._order_id_futures:
                    future = self._order_id_futures[cl_ord_id]
                    if not future.done():
                        future.set_result(ord_id)

            status = self.map_status(ord_status)

            payload = {
                "cl_ord_id": cl_ord_id,
                "order_id": ord_id,
                "status": status,
                "exec_type": exec_type,
                "at": transact_time,
            }

            if exec_type == fix.ExecType_REJECTED:
                text = (
                    message.getField(fix.Text().getTag())
                    if message.isSetField(fix.Text().getTag())
                    else "No reason"
                )
                self.logger.warning(
                    f"[REJECTED] Order {cl_ord_id} was rejected: {text}"
                )
                payload["reason"] = text
                self._update_status(
                    cl_ord_id, "Rejected", transact_time, text=text
                )
                self._emit("order:rejected", **payload)

            elif exec_type == fix.ExecType_TRADE:
                last_px = float(message.getField(fix.LastPx().getTag()))
                last_qty = float(message.getField(fix.LastQty().getTag()))
                cum_qty = float(message.getField(fix.CumQty().getTag())) if message.isSetField(fix.CumQty().getTag()) else 0.0
                leaves_qty = float(message.getField(fix.LeavesQty().getTag())) if message.isSetField(fix.LeavesQty().getTag()) else 0.0
                self.logger.info(
                    f"[TRADE] {cl_ord_id}: Traded {last_qty} @ {last_px} "
                    f"at {transact_time.isoformat()} "
                    f"(OrdStatus={ord_status})"
                )
                payload.update({
                    "last_px": last_px,
                    "last_qty": last_qty,
                    "cum_qty": cum_qty,
                    "leaves_qty": leaves_qty,
                })
                # Map "FILLED"/"PARTIALLY_FILLED" wire names to facade
                # form ("Filled"/"PartiallyFilled") used by status_map.
                facade_status = self._FACADE_STATUS.get(status, status)
                self._update_status(
                    cl_ord_id, facade_status, transact_time,
                    cum_qty=cum_qty, leaves_qty=leaves_qty,
                )

                if ord_status == "1":
                    self._emit("order:partial_fill", **payload)
                elif ord_status == "2":
                    self._emit("order:filled", **payload)
                else:
                    self._emit("order:trade", **payload)

            elif exec_type == fix.ExecType_PENDING_CANCEL:
                orig = self._resolve_orig_cl_ord_id(message, cl_ord_id)
                self.logger.debug(
                    f"[PENDING_CANCEL] {orig} pending cancel "
                    f"at {transact_time.isoformat()}"
                )
                self._update_status(orig, "PendingCancel", transact_time)
                payload["orig_cl_ord_id"] = orig
                self._emit("order:cancel_pending", **payload)

            elif exec_type == fix.ExecType_CANCELED:
                orig = self._resolve_orig_cl_ord_id(message, cl_ord_id)
                self.logger.info(
                    f"[CANCELED] {orig} was canceled "
                    f"at {transact_time.isoformat()}"
                )
                self._update_status(orig, "Canceled", transact_time)
                payload["orig_cl_ord_id"] = orig
                self._emit("order:canceled", **payload)

            elif exec_type == fix.ExecType_NEW:
                self.logger.info(
                    f"[NEW] Order {cl_ord_id} accepted "
                    f"at {transact_time.isoformat()}"
                )
                self._update_status(cl_ord_id, "New", transact_time)
                self._emit("order:accepted", **payload)

            elif exec_type == fix.ExecType_PENDING_NEW:
                self.logger.info(
                    f"[PENDING_NEW] {cl_ord_id} "
                    f"at {transact_time.isoformat()}"
                )
                self._update_status(cl_ord_id, "PendingNew", transact_time)
                self._emit("order:pending_new", **payload)

            else:
                # Covers ExecType=I (answer to an OrderStatusRequest) and any
                # exec type without a dedicated branch. Normalize to facade
                # names so callers see one spelling of each status.
                self._update_status(
                    cl_ord_id,
                    self._FACADE_STATUS.get(status, status),
                    transact_time,
                )
                self._emit("order:update", **payload)

        except Exception as e:
            self.logger.error(
                f"Failed to process execution report: {e}",
                exc_info=True,
            )

    # ---------- Queries ----------
    def get_order_status(self, cl_ord_id: str) -> str:
        with self._state_lock:
            entry = self.status_map.get(cl_ord_id)
            return entry["status"] if entry else "Unknown"

    def map_status(self, fix_status: str) -> str:
        return {
            "0": "NEW",
            "1": "PARTIALLY_FILLED",
            "2": "FILLED",
            "4": "CANCELED",
            "6": "PENDING_CANCEL",
            "8": "REJECTED",
            "A": "PENDING_NEW",
            "B": "CALCULATED",
            "C": "EXPIRED",
            "3": "DONE_FOR_DAY",
            "5": "REPLACED",
            "9": "SUSPENDED",
        }.get(fix_status, "UNKNOWN")

    # ---------- Queries (v0.2.6 facade) ----------
    def get_cumqty(self, cl_ord_id: str) -> int:
        """Cumulative filled quantity (int) — 0 if unknown."""
        with self._state_lock:
            entry = self.status_map.get(cl_ord_id) or {}
            return int(entry.get("cum_qty") or 0)

    def get_leavesqty(self, cl_ord_id: str) -> Optional[int]:
        """Remaining qty (LeavesQty) — None if not yet reported."""
        with self._state_lock:
            entry = self.status_map.get(cl_ord_id) or {}
            v = entry.get("leaves_qty")
            return int(v) if v is not None else None

    def get_order_text(self, cl_ord_id: str) -> Optional[str]:
        """Last Text(58) field from server (reject reason, etc) — None if absent."""
        with self._state_lock:
            entry = self.status_map.get(cl_ord_id) or {}
            return entry.get("text")

    def get_last_cancel_reject(self, cl_ord_id: str) -> Optional[dict]:
        """
        Detail of the last OrderCancelReject for this order, or None (v0.2.8).

        Returns ``{"code", "reason", "at", "cancel_cl_ord_id"}`` where ``code``
        is CxlRejReason(102) and ``reason`` is Text(58). Lets a caller tell
        "cancel refused, stop waiting" from "cancel still in flight" without
        string-matching free text.
        """
        with self._state_lock:
            rej = self._cancel_rejects.get(cl_ord_id)
            return dict(rej) if rej else None

    def is_order_done(self, cl_ord_id: str) -> bool:
        """True if order reached a terminal state."""
        return self.get_order_status(cl_ord_id) in self.TERMINAL_STATUSES

    def cleanup_order(self, cl_ord_id: str) -> None:
        """
        Drop in-memory state for an order. Useful after a terminal status
        is observed and the alpha no longer needs to wait on it.

        Does NOT touch persistent store — recovery of the same cl_ord_id
        is still possible in a new process (rare but supported).
        """
        with self._state_lock:
            self.order_info.pop(cl_ord_id, None)
            self.status_map.pop(cl_ord_id, None)
            oid = self.order_id_map.pop(cl_ord_id, None)
            if oid:
                self.clord_map.pop(oid, None)
            self._cancel_seq.pop(cl_ord_id, None)
            self._pre_cancel_status.pop(cl_ord_id, None)
            self._cancel_rejects.pop(cl_ord_id, None)
            for cxl in [
                k for k, v in self._cancel_clord_map.items()
                if v == cl_ord_id
            ]:
                self._cancel_clord_map.pop(cxl, None)
        with self._futures_lock:
            self._order_id_futures.pop(cl_ord_id, None)
            self._status_events.pop(cl_ord_id, None)

    # ---------- Internals ----------
    def _update_status(
        self,
        cl_ord_id: str,
        status: str,
        at: datetime,
        *,
        cum_qty: Optional[float] = None,
        leaves_qty: Optional[float] = None,
        text: Optional[str] = None,
        local_time: bool = False,
    ) -> None:
        """
        Apply a status transition, newest-wins.

        ``local_time=True`` marks ``at`` as stamped from *our* clock (an
        optimistic PendingNew/PendingCancel) rather than a server TransactTime.
        A local stamp never blocks the next server report: if the server clock
        runs behind ours, a plain ``at > prev["time"]`` test would silently
        drop the real ExecutionReport and freeze the order.
        """
        with self._state_lock:
            prev = self.status_map.get(cl_ord_id)
            supersedes = (
                prev is None
                or at > prev["time"]
                or prev.get("local_time", False)
            )
            if supersedes:
                entry: Dict = {"status": status, "time": at}
                if local_time:
                    entry["local_time"] = True
                # Preserve sticky cum/leaves/text from prev if not overridden
                if prev is not None:
                    for k in ("cum_qty", "leaves_qty", "text"):
                        if k in prev:
                            entry[k] = prev[k]
                if cum_qty is not None:
                    entry["cum_qty"] = cum_qty
                if leaves_qty is not None:
                    entry["leaves_qty"] = leaves_qty
                if text is not None:
                    entry["text"] = text
                self.status_map[cl_ord_id] = entry

        if self._store:
            order_id = None
            with self._state_lock:
                order_id = self.order_id_map.get(cl_ord_id)
            self._store.update_status(cl_ord_id, status, order_id=order_id)

        with self._futures_lock:
            ev = self._status_events.setdefault(
                cl_ord_id, threading.Event()
            )
            ev.set()

        self._emit(
            "order:update",
            cl_ord_id=cl_ord_id,
            status=status,
            at=at,
        )

    # ---------- Recovery hooks (called by RecoveryManager) ----------
    def rehydrate(self, rows: List[Dict]) -> None:
        """
        Repopulate in-memory state from rows loaded by RecoveryManager.

        Touches private state maps under lock, so it lives on OrderManager
        rather than in RecoveryManager. Idempotent — skips entries that
        already exist in memory.
        """
        for row in rows:
            cid = row["cl_ord_id"]
            with self._state_lock:
                if cid not in self.order_info:
                    self.order_info[cid] = {
                        "symbol": row["symbol"],
                        "side": row["side"],
                        "qty": row["qty"],
                        "exchange": row["exchange"],
                        "price": row["price"],
                    }
                if cid not in self.status_map:
                    self.status_map[cid] = {
                        "status": row["status"],
                        "time": datetime.now(timezone.utc),
                    }
                oid = row.get("order_id")
                if oid and cid not in self.order_id_map:
                    self.order_id_map[cid] = oid
                    self.clord_map[oid] = cid

            oid = row.get("order_id")
            if oid:
                with self._futures_lock:
                    if cid not in self._order_id_futures:
                        f = Future()
                        f.set_result(oid)
                        self._order_id_futures[cid] = f

    def get_active_orders_from_store(self) -> List[Dict]:
        """
        Back-compat shim — delegates to RecoveryManager.

        Pre-v0.2.5 callers (e.g. `PaperBrokerClient.recover_pending_orders`)
        used this method. The recovery class is now the canonical entry
        point; this shim keeps old signature working.
        """
        from paperbroker.execution.recovery import RecoveryManager
        return RecoveryManager(self._store, self).get_active_orders()
