"""
FIX engine — unified session lifecycle + QuickFIX Application.

Merges (v0.2.5):
    - paperbroker.session.session_manager.FIXSessionManager (lifecycle)
    - paperbroker.session.app.FIXApp                       (QuickFIX callbacks)
    - paperbroker.session.handler_admin.AdminHandler       (admin msg injection)
    - paperbroker.session.handler_app.AppHandler           (app msg injection)
    - paperbroker.session.handler_logon.LogonHandler       (logon logging)

The 3 thin handlers (89-120L each) had no independent SRP — they were split
along QuickFIX callback shape, not domain responsibility. They are now
private methods on FIXEngine.
"""
import logging
import threading
from typing import Callable, Optional, TYPE_CHECKING

import quickfix as fix

from paperbroker.events import EventBus
from paperbroker.logger import get_logger
from .order_manager import OrderManager
from .order_store import OrderStore

if TYPE_CHECKING:
    from paperbroker.sub_account import SubAccountProvider


logger = logging.getLogger(__name__)


class FIXEngine(fix.Application):
    """
    Unified FIX engine: lifecycle + QuickFIX Application in one class.

    Combines what was previously FIXSessionManager (lifecycle wrapper)
    and FIXApp (QuickFIX Application impl), with the 3 thin handlers
    (admin/app/logon) inlined as private methods.

    Thread Safety:
        All public methods are thread-safe. QuickFIX engine manages
        its own I/O threads.

    Example:
        engine = FIXEngine(
            cfg_path="config.cfg",
            sub_provider=sub,
            username="trader",
            password="secret",
            bus=bus,
        )
        engine.start()
        if engine.wait_until_logged_on(timeout=10):
            engine.order_manager.place_order(...)
        engine.stop()
    """

    def __init__(
        self,
        *,
        cfg_path: str,
        sub_provider: "SubAccountProvider",
        username: str,
        password: str,
        bus: EventBus,
        log_dir: str = "logs",
        console: bool = False,
        order_store: Optional[OrderStore] = None,
        log_propagate: bool = False,
        fix_message_log: bool = True,
    ):
        super().__init__()

        self.logger = get_logger(log_dir, console, propagate=log_propagate)
        self.bus = bus
        self._sub_provider = sub_provider
        self._username = username
        self._password = password

        # QuickFIX initiator. With a LogFactory, QuickFIX writes its own
        # standard message log (both directions, raw wire) under FileLogPath —
        # the answer to "did we actually send that?". Needs FileLogPath in the
        # cfg; fall back silently if a caller-supplied cfg omits it.
        self.settings = fix.SessionSettings(cfg_path)
        self.store_factory = fix.FileStoreFactory(self.settings)
        self.log_factory: Optional[fix.LogFactory] = None
        if fix_message_log:
            try:
                self.log_factory = fix.FileLogFactory(self.settings)
            except Exception as e:
                self.logger.warning(
                    "FIX message log disabled (no FileLogPath in config): "
                    f"{e}"
                )
        if self.log_factory is not None:
            self.initiator = fix.SocketInitiator(
                self, self.store_factory, self.settings, self.log_factory
            )
        else:
            self.initiator = fix.SocketInitiator(
                self, self.store_factory, self.settings
            )

        # Logon state
        self._session_id: Optional[fix.SessionID] = None
        self._logon_event = threading.Event()
        self._last_logon_error: Optional[str] = None
        self._last_logout_reason: Optional[str] = None

        # Order manager (own emitter bridges to global bus)
        self.order_manager = OrderManager(
            logger=self.logger,
            emit=self._emit_fix,
            store=order_store,
        )

        # Back-compat: old code accessed `manager.app.order_manager`.
        # FIXEngine *is* the application now, so expose `self.app = self`.
        self.app = self

        self.logger.debug(
            "FIXEngine initialized",
            extra={"config": cfg_path, "username": username},
        )

    # -------- Lifecycle --------
    def start(self) -> None:
        self.logger.info("Starting FIX session...")
        self.initiator.start()

    def stop(self) -> None:
        self.logger.info("Stopping FIX session...")
        self.initiator.stop()

    def is_logged_on(self) -> bool:
        return self._logon_event.is_set()

    def wait_until_logged_on(
        self, timeout: Optional[float] = None
    ) -> bool:
        return self._logon_event.wait(timeout=timeout)

    def last_logon_error(self) -> Optional[str]:
        return self._last_logon_error

    def last_logout_reason(self) -> Optional[str]:
        """Reason text from the last server Logout (Text/58 field), or None."""
        return self._last_logout_reason

    def get_session_id(self) -> Optional[fix.SessionID]:
        return self._session_id

    # -------- Order façade (back-compat) --------
    def place_order(
        self,
        full_symbol: str,
        side: str,
        qty: int,
        price: float,
        ord_type: str = "LIMIT",
        tif: str = "GTC",
    ) -> str:
        return self.order_manager.place_order(
            full_symbol=full_symbol,
            side=side,
            qty=qty,
            price=price,
            ord_type=ord_type,
            tif=tif,
        )

    def cancel_order(
        self, cl_ord_id: str, timeout: float = 2.0
    ) -> None:
        return self.order_manager.cancel_order(
            cl_ord_id=cl_ord_id, timeout=timeout
        )

    def get_order_status(self, cl_ord_id: str) -> str:
        return self.order_manager.get_order_status(cl_ord_id)

    def request_order_status(self, cl_ord_id: str) -> bool:
        """Send OrderStatusRequest (35=H) to reconcile a disputed state."""
        return self.order_manager.request_order_status(cl_ord_id)

    # -------- QuickFIX callbacks --------
    def onCreate(self, sessionID) -> None:  # noqa: N802
        self._session_id = sessionID
        try:
            self.logger.info(f"Session created: {sessionID}")
        except Exception as e:
            self.logger.error(
                "event=onCreate_handler_failed",
                extra={"error": str(e)},
            )

    def onLogon(self, sessionID) -> None:  # noqa: N802
        self._session_id = sessionID
        self._last_logon_error = None
        self._logon_event.set()
        try:
            self.logger.info(f"Logon success: {sessionID}")
            self.order_manager.set_session(sessionID)
        finally:
            self._safe_emit("logon", session_id=sessionID)

    def onLogout(self, sessionID) -> None:  # noqa: N802
        self._logon_event.clear()
        try:
            self.logger.info(f"Logged out: {sessionID}")
        finally:
            self._safe_emit(
                "logout",
                session_id=sessionID,
                reason=self._last_logout_reason,
            )

    def toAdmin(self, message, sessionID) -> None:  # noqa: N802
        try:
            self._inject_admin_credentials(message, sessionID)
        except Exception as e:
            self.logger.error(
                "event=toAdmin_handler_failed",
                extra={"error": str(e)},
            )

    def fromAdmin(self, message, sessionID) -> None:  # noqa: N802
        try:
            self.logger.debug(f"[FROM ADMIN] {message}")
        except Exception as e:
            self.logger.error(
                "event=fromAdmin_handler_failed",
                extra={"error": str(e)},
            )

        # Capture any Logout reason (Text/58) regardless of when it arrives.
        try:
            msg_type = fix.MsgType()
            message.getHeader().getField(msg_type)
            if msg_type.getValue() == fix.MsgType_Logout:
                text = (
                    message.getField(58)
                    if message.isSetField(58)
                    else None
                )
                if text is not None:
                    self._last_logout_reason = text
                # Distinguish "Logout before logon" (= logon error)
                # from "Logout after logged-on session" (= normal disconnect).
                if not self.is_logged_on():
                    self._last_logon_error = text or "Logout during logon"
                    self._logon_event.clear()
                    self._safe_emit(
                        "logon_error",
                        session_id=sessionID,
                        reason=self._last_logon_error,
                    )
        except Exception as e:
            self.logger.error(
                "event=fromAdmin_logon_error_detection_failed",
                extra={"error": str(e)},
            )

    def toApp(self, message, sessionID) -> None:  # noqa: N802
        try:
            self._inject_app_credentials(message, sessionID)
        except Exception as e:
            self.logger.error(
                "event=toApp_handler_failed",
                extra={"error": str(e)},
            )

        # Log outbound at INFO, symmetric with fromApp — half a conversation
        # is not enough to settle a client/server disagreement. Logged after
        # injection so the line shows what actually went on the wire, and
        # outside the try above so an injection failure still gets recorded.
        try:
            self.logger.info(f"[TO APP] {message}")
        except Exception:  # pragma: no cover - logging must never break send
            pass

    def fromApp(self, message, sessionID) -> None:  # noqa: N802
        try:
            self.logger.info(f"[FROM APP] {message}")
        except Exception as e:
            self.logger.error(
                "event=fromApp_handler_failed",
                extra={"error": str(e)},
            )

        # Route ExecutionReport (35=8) and OrderCancelReject to OrderManager
        try:
            msg_type = fix.MsgType()
            message.getHeader().getField(msg_type)
            mv = msg_type.getValue()
            if mv == fix.MsgType_ExecutionReport or mv == fix.MsgType_OrderCancelReject:
                self.order_manager.on_execution_report(message)
            elif mv == fix.MsgType_BusinessMessageReject:
                # e.g. a refused OrderStatusRequest — must not vanish.
                self.order_manager.on_business_reject(message)
        except Exception as e:
            self.logger.error(
                "event=order_manager_execution_report_failed",
                extra={"error": str(e)},
            )

    # -------- Private: credential injection (was 3 handler classes) --------
    def _inject_admin_credentials(self, message, sessionID) -> None:
        """Inline of AdminHandler.to_admin (was paperbroker/session/handler_admin.py)."""
        msg_type = message.getHeader().getField(fix.MsgType()).getString()

        if msg_type == "A":  # Logon
            message.setField(fix.Password(self._password))
            message.setField(fix.EncryptMethod(0))
            message.setField(fix.HeartBtInt(30))

        message.setField(fix.Username(self._username))
        message.setField(fix.Account(self._sub_provider.current()))

        self.logger.debug(f"[TO ADMIN] {message}")

    def _inject_app_credentials(self, message, sessionID) -> None:
        """Inline of AppHandler.to_app (was paperbroker/session/handler_app.py)."""
        message.setField(fix.Username(self._username))
        message.setField(fix.Account(self._sub_provider.current()))

    # -------- Internal --------
    def _emit_fix(self, event: str, **kw) -> None:
        """Bridge order-manager events to global bus with 'fix:' prefix."""
        self.bus.emit(f"fix:{event}", **kw)

    def _safe_emit(self, event: str, **payload) -> None:
        try:
            self._emit_fix(event, **payload)
        except Exception as e:
            self.logger.error(
                "event=emit_failed",
                extra={"event": event, "error": str(e)},
            )
