"""
Unified PaperBroker client for FIX and REST trading operations.

v0.2.5 refactor:
    - PaperBrokerRESTClient (separate facade) is merged in via ``enable_fix=False``
    - FIX engine + REST account client exposed as public attrs:
        ``self.orders``     — FIX order manager (None if enable_fix=False)
        ``self.accounting`` — REST account client
    - Order pass-through methods are 1-hop (``self.orders.place_order``) instead
      of 3-hop through ``self.session.app.order_manager``.
    - QuickFIX is imported lazily so Mac arm64 (no QuickFIX) can still
      construct the client with ``enable_fix=False`` and use REST.
"""
from typing import Callable, Dict, List, Optional

from paperbroker.events import EventBus
from paperbroker.rest.account import AccountClient
from paperbroker.rest.session import RestSession
from paperbroker.sub_account import SubAccountProvider


def _quickfix_available() -> bool:
    try:
        import quickfix  # noqa: F401
        return True
    except Exception:
        return False


class FIXNotEnabledError(RuntimeError):
    """Raised when a FIX-only method is called on a REST-only client."""


class PaperBrokerClient:
    """
    Unified trading client.

    The same class now serves both modes:
        - Full mode (enable_fix=True or auto-detected): FIX order execution
          + REST account queries.
        - REST-only mode (enable_fix=False): account queries only — order
          methods raise FIXNotEnabledError. Use this on platforms where
          QuickFIX is unavailable (e.g. macOS arm64).

    Public attributes after construction:
        bus          : EventBus
        sub_provider : SubAccountProvider
        orders       : OrderManager | None (FIX mode only)
        accounting   : AccountClient
        session      : FIXEngine | None  (back-compat alias for orders' engine)

    Example (full mode):
        client = PaperBrokerClient(default_sub_account="main", username=..., password=...)
        client.connect()
        client.wait_until_logged_on(timeout=10)
        cl_ord_id = client.place_order("HSX:VNM", "BUY", 100, 75000)

    Example (REST-only mode):
        client = PaperBrokerClient(
            default_sub_account="main",
            username=..., password=...,
            enable_fix=False,
        )
        balance = client.get_cash_balance()
        # client.place_order(...) would raise FIXNotEnabledError
    """

    def __init__(
        self,
        default_sub_account: str,
        username: str,
        password: str,
        rest_base_url: str = "http://localhost:8000",
        socket_connect_host: str = "localhost",
        socket_connect_port: int = 5001,
        sender_comp_id: str = "CLIENT",
        target_comp_id: str = "SERVER",
        cfg_path: Optional[str] = None,
        auto_generate_cfg: bool = True,
        save_cfg_to: Optional[str] = None,
        log_dir: str = "logs",
        console: bool = False,
        order_store_path: Optional[str] = "orders.db",
        enable_fix: Optional[bool] = None,
        log_propagate: bool = False,
        fix_message_log: bool = True,
    ):
        """
        Initialize PaperBroker client.

        Args:
            default_sub_account: Default sub-account ID.
            username, password:  Trading account credentials.
            rest_base_url:       Base URL for REST API.
            socket_connect_host/port: FIX server connection.
            sender_comp_id, target_comp_id: FIX CompIDs.
            cfg_path:            Path to QuickFIX .cfg, or None to auto-generate.
            auto_generate_cfg:   Generate QuickFIX config if cfg_path=None.
            save_cfg_to:         If set, write generated config to this path.
            log_dir, console:    Logging.
            order_store_path:    SQLite path for order persistence (None = memory only).
            enable_fix:          True/False to force; None (default) auto-detects
                                 QuickFIX availability.
            log_propagate:       Let package log records reach ancestor loggers,
                                 so a host app sees them in its own log tree.
                                 Default False (package logs stay in log_dir).
            fix_message_log:     Let QuickFIX write its standard raw message log
                                 (both directions) under log_dir. Default True.
        """
        self.bus = EventBus()

        self.sub_provider = SubAccountProvider(default_sub_account)
        self.sub_provider.on_switch(
            lambda **kw: self.bus.emit("account:switch", **kw)
        )

        # FIX mode decision: explicit True/False overrides auto-detect.
        if enable_fix is None:
            enable_fix = _quickfix_available()
        self._fix_enabled = enable_fix

        # Order persistence (only meaningful in FIX mode but allocate either way
        # so external code reading ``client._order_store`` doesn't NPE).
        self._order_store = None
        if enable_fix and order_store_path is not None:
            # Lazy import: only touch fix.order_store if we are enabling FIX.
            from paperbroker.fix.order_store import OrderStore
            self._order_store = OrderStore(db_path=order_store_path)

        # ----- FIX engine -----
        if enable_fix:
            self._engine = self._init_fix_engine(
                cfg_path=cfg_path,
                auto_generate_cfg=auto_generate_cfg,
                save_cfg_to=save_cfg_to,
                socket_connect_host=socket_connect_host,
                socket_connect_port=socket_connect_port,
                sender_comp_id=sender_comp_id,
                target_comp_id=target_comp_id,
                username=username,
                password=password,
                log_dir=log_dir,
                console=console,
                log_propagate=log_propagate,
                fix_message_log=fix_message_log,
            )
            self.orders = self._engine.order_manager
        else:
            self._engine = None
            self.orders = None

        # Back-compat alias: code that accessed ``client.session`` keeps working.
        self.session = self._engine

        # ----- REST -----
        self.rest_session = RestSession(rest_base_url)
        self.accounting = AccountClient(
            rest_session=self.rest_session,
            sub_provider=self.sub_provider,
            username=username,
            password=password,
            log_dir=log_dir,
            console=console,
            log_propagate=log_propagate,
        )
        # Back-compat alias (was self.account_client).
        self.account_client = self.accounting

    def _init_fix_engine(
        self,
        *,
        cfg_path: Optional[str],
        auto_generate_cfg: bool,
        save_cfg_to: Optional[str],
        socket_connect_host: str,
        socket_connect_port: int,
        sender_comp_id: str,
        target_comp_id: str,
        username: str,
        password: str,
        log_dir: str,
        console: bool,
        log_propagate: bool = False,
        fix_message_log: bool = True,
    ):
        from paperbroker.config import render_quickfix_cfg
        from paperbroker.fix.engine import FIXEngine

        if cfg_path is None and auto_generate_cfg:
            cfg_path = render_quickfix_cfg(
                socket_host=socket_connect_host,
                socket_port=socket_connect_port,
                sender_comp_id=sender_comp_id,
                target_comp_id=target_comp_id,
                file_store_path=f"{log_dir}/client_fix_messages/",
                file_log_path=f"{log_dir}/",
                save_as=save_cfg_to,
            )
        elif cfg_path is None:
            raise ValueError(
                "Either provide cfg_path or set auto_generate_cfg=True"
            )

        return FIXEngine(
            cfg_path=cfg_path,
            sub_provider=self.sub_provider,
            username=username,
            password=password,
            bus=self.bus,
            log_dir=log_dir,
            console=console,
            order_store=self._order_store,
            log_propagate=log_propagate,
            fix_message_log=fix_message_log,
        )

    # -------- Lifecycle --------
    def connect(self) -> None:
        """Start FIX session (if enabled) and resolve REST account ID."""
        if self._engine is not None:
            self._engine.start()
        self.accounting.resolve_on_connect()

    def disconnect(self) -> None:
        if self._engine is not None:
            self._engine.stop()

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.disconnect()

    def _ensure_account_id(self) -> bool:
        return self.accounting._ensure_account_id()

    @property
    def is_fix_enabled(self) -> bool:
        return self._fix_enabled

    # -------- Event API --------
    def on(self, event: str, fn: Callable[..., None]) -> None:
        self.bus.on(event, fn)

    def off(self, event: str, fn: Callable[..., None]) -> None:
        self.bus.off(event, fn)

    # -------- FIX lifecycle helpers --------
    def is_logged_on(self) -> bool:
        return self._engine.is_logged_on() if self._engine else False

    def wait_until_logged_on(self, timeout: Optional[float] = None) -> bool:
        if self._engine is None:
            return False
        return self._engine.wait_until_logged_on(timeout)

    def last_logon_error(self) -> Optional[str]:
        return self._engine.last_logon_error() if self._engine else None

    def last_logout_reason(self) -> Optional[str]:
        """Text/58 from the last server Logout (symmetric with last_logon_error)."""
        return self._engine.last_logout_reason() if self._engine else None

    def get_session_id(self):
        return self._engine.get_session_id() if self._engine else None

    # -------- Order façade (1 hop to OrderManager) --------
    def _require_fix(self) -> None:
        if self.orders is None:
            raise FIXNotEnabledError(
                "This method requires FIX (enable_fix=True). "
                "Construct with enable_fix=True or install QuickFIX."
            )

    def place_order(
        self,
        full_symbol: str,
        side: str,
        qty: int,
        price: float,
        ord_type: str = "LIMIT",
        tif: str = "DAY",
    ) -> str:
        self._require_fix()
        return self.orders.place_order(
            full_symbol=full_symbol,
            side=side,
            qty=qty,
            price=price,
            ord_type=ord_type,
            tif=tif,
        )

    def cancel_order(
        self, cl_ord_id: str, timeout: float = 2.0
    ) -> "tuple[bool, str]":
        """
        Cancel an order and wait for the server response (v0.2.6 signature).

        Returns ``(is_terminal, status)``:
            - ``is_terminal=True`` means the server confirmed a terminal
              state within timeout (Canceled / Filled / Rejected / Expired).
            - ``False`` means the order is still PendingCancel or the
              cancel itself was rejected.

        Pre-v0.2.6 callers used a ``None``-returning fire-and-forget API.
        Migrate or use ``cancel_order_v1`` (deprecated shim) for the
        old behavior.
        """
        self._require_fix()
        return self.orders.cancel_order(cl_ord_id=cl_ord_id, timeout=timeout)

    def cancel_order_v1(self, cl_ord_id: str, timeout: float = 2.0) -> None:
        """Legacy fire-and-forget cancel — deprecated shim, removed in v0.3.0."""
        self._require_fix()
        return self.orders.cancel_order_v1(cl_ord_id=cl_ord_id, timeout=timeout)

    def wait_for(
        self,
        cl_ord_id: str,
        statuses,
        timeout: Optional[float] = None,
    ) -> bool:
        """Block until ``cl_ord_id`` reaches one of ``statuses`` or timeout."""
        self._require_fix()
        return self.orders.wait_for(cl_ord_id, statuses, timeout=timeout)

    def is_order_done(self, cl_ord_id: str) -> bool:
        """True if order has reached a terminal state."""
        if self.orders is None:
            return False
        return self.orders.is_order_done(cl_ord_id)

    def cleanup_order(self, cl_ord_id: str) -> None:
        """Drop in-memory state for a settled order. No-op in REST-only mode."""
        if self.orders is None:
            return
        self.orders.cleanup_order(cl_ord_id)

    def get_order_cumqty(self, cl_ord_id: str) -> int:
        """Cumulative filled quantity (0 if unknown)."""
        if self.orders is None:
            return 0
        return self.orders.get_cumqty(cl_ord_id)

    def get_order_leavesqty(self, cl_ord_id: str) -> Optional[int]:
        """Remaining qty (None if not yet reported)."""
        if self.orders is None:
            return None
        return self.orders.get_leavesqty(cl_ord_id)

    def get_order_text(self, cl_ord_id: str) -> Optional[str]:
        """Last Text(58) field for an order (reject reason etc); None if absent."""
        if self.orders is None:
            return None
        return self.orders.get_order_text(cl_ord_id)

    def get_last_cancel_reject(self, cl_ord_id: str) -> Optional[Dict]:
        """
        Last OrderCancelReject detail for an order, or None (v0.2.8).

        ``{"code", "reason", "at", "cancel_cl_ord_id"}`` — lets a caller
        distinguish a refused cancel from one still in flight.
        """
        if self.orders is None:
            return None
        return self.orders.get_last_cancel_reject(cl_ord_id)

    def request_order_status(self, cl_ord_id: str) -> bool:
        """
        Ask the server for an order's authoritative state (35=H, v0.2.8).

        Use when local state and the server disagree. The answer arrives as an
        ExecutionReport and updates local state; returns True if the request
        was sent.
        """
        self._require_fix()
        return self.orders.request_order_status(cl_ord_id)

    def recover_pending_orders(self) -> List[Dict]:
        """
        Load active orders from persistent store + rehydrate in-memory state
        so cancel_order() works immediately on them.
        """
        if self.orders is None:
            return []
        from paperbroker.execution.recovery import RecoveryManager
        return RecoveryManager(self._order_store, self.orders).get_active_orders()

    def get_order_status(self, cl_ord_id: str) -> str:
        self._require_fix()
        return self.orders.get_order_status(cl_ord_id)

    # -------- REST façade --------
    def get_cash_balance(self):
        return self.accounting.get_remain_balance()

    def get_account_balance(self):
        return self.accounting.get_total_balance()

    def get_stock_orders(self):
        return self.accounting.get_stock_orders()

    def get_derivative_orders(self):
        return self.accounting.get_derivative_orders()

    def get_portfolio_by_sub(self, sub_account_id: Optional[str] = None) -> dict:
        if sub_account_id:
            with self.use_sub_account(sub_account_id):
                return self.accounting.get_portfolio_by_sub()
        return self.accounting.get_portfolio_by_sub()

    def get_orders(
        self,
        start_date: str,
        end_date: str,
        sub_account_id: Optional[str] = None,
    ) -> dict:
        if sub_account_id:
            with self.use_sub_account(sub_account_id):
                return self.accounting.get_orders(start_date, end_date)
        return self.accounting.get_orders(start_date, end_date)

    def get_transactions_by_date(
        self,
        start_date: str,
        end_date: str,
        sub_account_id: Optional[str] = None,
    ) -> dict:
        if sub_account_id:
            with self.use_sub_account(sub_account_id):
                return self.accounting.get_transactions_by_date(start_date, end_date)
        return self.accounting.get_transactions_by_date(start_date, end_date)

    def get_max_placeable(
        self,
        symbol: str,
        price: float,
        side: str,
        sub_account_id: Optional[str] = None,
    ) -> dict:
        if sub_account_id:
            with self.use_sub_account(sub_account_id):
                return self.accounting.get_max_placeable(symbol, price, side)
        return self.accounting.get_max_placeable(symbol, price, side)

    # -------- Sub-account façade --------
    def set_default_sub_account(self, sub_id: str) -> None:
        self.sub_provider.set_default(sub_id)

    def current_sub_account(self) -> str:
        return self.sub_provider.current()

    def use_sub_account(self, sub_id: str):
        return self.sub_provider.use(sub_id)
