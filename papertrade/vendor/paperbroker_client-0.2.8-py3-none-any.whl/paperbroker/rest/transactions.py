"""
Transaction history endpoints.

Split from paperbroker.rest.account_client in v0.2.5. Implemented as a
mixin so AccountClient composes it without changing its public surface.
"""
from typing import Any, Dict, List


class AccountTransactionsMixin:
    """
    Transaction-history endpoints.

    Requires host class fields: ``self.rest``, ``self.sub``, ``self.username``,
    ``self.ID``, ``self.logger``, ``self._ensure_account_id``.
    """

    def get_transactions(self) -> List[Dict[str, Any]]:
        """Fetch all transactions for current account."""
        if not self._ensure_account_id():
            self.logger.warning(
                "event=transactions_skipped_due_to_missing_id",
                extra={"username": self.username},
            )
            return []

        try:
            response = self.rest.get(
                "/api/account/transactions",
                params={"accountID": self.ID},
            )
            if isinstance(response, list):
                self.logger.info(
                    "event=transactions_resolved",
                    extra={"accountID": self.ID, "count": len(response)},
                )
                return response
            self.logger.warning(
                "event=transactions_invalid_format",
                extra={"accountID": self.ID, "response": str(response)},
            )
            return []
        except Exception as e:
            self.logger.error(
                "event=transactions_fetch_failed",
                extra={"accountID": self.ID, "error": str(e)},
            )
            return []

    def get_transactions_by_date(
        self,
        start_date: str,
        end_date: str,
    ) -> Dict[str, Any]:
        """
        Fetch transactions for current sub-account within date range.

        Args:
            start_date: yyyy-MM-dd
            end_date: yyyy-MM-dd
        """
        if not self._ensure_account_id():
            self.logger.warning(
                "event=transactions_skipped_due_to_missing_account_id",
                extra={"username": self.username},
            )
            return {}

        current_sub = self.sub.current()

        try:
            payload = {
                "fixAccountID": self.ID,
                "subAccountID": current_sub,
                "startTime": start_date,
                "endTime": end_date,
            }

            self.logger.debug(
                "event=transactions_request",
                extra={
                    "fixAccountID": self.ID,
                    "subAccountID": current_sub,
                    "startTime": start_date,
                    "endTime": end_date,
                },
            )

            response = self.rest.post(
                "/api/transaction-by-sub/list",
                json=payload,
            )

            if isinstance(response, dict):
                success = response.get("success", False)
                items = response.get("items", [])

                self.logger.info(
                    "event=transactions_resolved",
                    extra={
                        "fixAccountID": self.ID,
                        "subAccountID": current_sub,
                        "count": len(items),
                        "success": success,
                    },
                )

                return {
                    "success": success,
                    "items": items,
                }
            self.logger.warning(
                "event=transactions_invalid_format",
                extra={
                    "fixAccountID": self.ID,
                    "subAccountID": current_sub,
                    "response": str(response),
                },
            )
            return {}
        except Exception as e:
            self.logger.error(
                "event=transactions_fetch_failed",
                extra={
                    "fixAccountID": self.ID,
                    "subAccountID": current_sub,
                    "error": str(e),
                },
            )
            return {}
