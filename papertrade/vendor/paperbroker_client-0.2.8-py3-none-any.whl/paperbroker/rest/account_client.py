"""Deprecation shim — split into rest/account.py + rest/metrics.py + rest/transactions.py in v0.2.5."""
import warnings

warnings.warn(
    "paperbroker.rest.account_client is deprecated; the 1338-line AccountClient "
    "was split by cohesion into paperbroker.rest.account + .metrics + .transactions "
    "in v0.2.5. The public AccountClient class composes them via mixins — "
    "public surface is unchanged. This shim will be removed in v0.3.0.",
    DeprecationWarning,
    stacklevel=2,
)

from paperbroker.rest.account import AccountClient  # noqa: F401,E402

__all__ = ["AccountClient"]
