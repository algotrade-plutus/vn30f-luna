"""
HTTP REST session wrapper with error handling.

Renamed from ``rest/rest_session.py`` in v0.2.5. Old import path still
works via shim at the previous location.

Provides simple HTTP client for REST API communication with automatic
error handling and response parsing.
"""
import logging
from typing import Any, Dict, Optional

import requests


logger = logging.getLogger(__name__)


class RestSession:
    """
    Simple HTTP REST client wrapper around the requests library.
    """

    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")
        logger.debug(f"RestSession initialized with base_url: {self.base_url}")

    def post(
        self,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        timeout: float = 30.0,
    ) -> Any:
        url = f"{self.base_url}{path}"

        logger.debug(
            f"POST {url}",
            extra={"payload_keys": list(json.keys()) if json else []},
        )

        try:
            response = requests.post(url, json=json, timeout=timeout)
            response.raise_for_status()

            result = response.json()
            logger.debug(
                f"POST {url} succeeded",
                extra={"status_code": response.status_code},
            )
            return result

        except requests.HTTPError as e:
            logger.error(
                f"POST {url} HTTP error",
                extra={
                    "status_code": e.response.status_code,
                    "response_text": e.response.text[:200],
                },
                exc_info=True,
            )
            raise
        except requests.Timeout:
            logger.error(f"POST {url} timed out after {timeout}s")
            raise
        except Exception as e:
            logger.error(
                f"POST {url} failed: {e}",
                exc_info=True,
            )
            raise

    def get(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: float = 30.0,
    ) -> Any:
        url = f"{self.base_url}{path}"

        logger.debug(
            f"GET {url}",
            extra={"params": params or {}},
        )

        try:
            response = requests.get(url, params=params, timeout=timeout)
            response.raise_for_status()

            result = response.json()
            logger.debug(
                f"GET {url} succeeded",
                extra={"status_code": response.status_code},
            )
            return result

        except requests.HTTPError as e:
            logger.error(
                f"GET {url} HTTP error",
                extra={
                    "status_code": e.response.status_code,
                    "response_text": e.response.text[:200],
                },
                exc_info=True,
            )
            raise
        except requests.Timeout:
            logger.error(f"GET {url} timed out after {timeout}s")
            raise
        except Exception as e:
            logger.error(
                f"GET {url} failed: {e}",
                exc_info=True,
            )
            raise
