"""
Account analytics endpoints — executions, NAV, drawdown.

Split from paperbroker.rest.account_client in v0.2.5. Implemented as a
mixin so AccountClient can compose multiple cohesion-split modules
without changing its public surface.
"""
from typing import Any, Dict, List


class AccountMetricsMixin:
    """
    Analytics endpoints split out of AccountClient.

    Requires the host class to provide: ``self.rest``, ``self.username``,
    ``self.ID``, ``self.logger``, ``self._ensure_account_id``.
    """

    def get_executions_by_order(self, order_id: str) -> List[Dict[str, Any]]:
        """Fetch all executions for a specific order."""
        try:
            response = self.rest.get(
                "/api/account/executions/by-order",
                params={"orderID": order_id},
            )
            if isinstance(response, list):
                self.logger.info(
                    "event=executions_by_order_resolved",
                    extra={"orderID": order_id, "count": len(response)},
                )
                return response
            self.logger.warning(
                "event=executions_by_order_invalid_format",
                extra={"orderID": order_id, "response": str(response)},
            )
            return []
        except Exception as e:
            self.logger.error(
                "event=executions_by_order_fetch_failed",
                extra={"orderID": order_id, "error": str(e)},
            )
            return []

    def get_executions_by_account(self) -> List[Dict[str, Any]]:
        """Fetch all executions for current account."""
        if not self._ensure_account_id():
            self.logger.warning(
                "event=executions_by_account_skipped_due_to_missing_id",
                extra={"username": self.username},
            )
            return []

        try:
            response = self.rest.get(
                "/api/account/executions/by-account",
                params={"accountID": self.ID},
            )
            if isinstance(response, list):
                self.logger.info(
                    "event=executions_by_account_resolved",
                    extra={"accountID": self.ID, "count": len(response)},
                )
                return response
            self.logger.warning(
                "event=executions_by_account_invalid_format",
                extra={"accountID": self.ID, "response": str(response)},
            )
            return []
        except Exception as e:
            self.logger.error(
                "event=executions_by_account_fetch_failed",
                extra={"accountID": self.ID, "error": str(e)},
            )
            return []

    def get_nav_history(self) -> List[Dict[str, Any]]:
        """Fetch NAV (Net Asset Value) time series."""
        if not self._ensure_account_id():
            self.logger.warning(
                "event=nav_skipped_due_to_missing_id",
                extra={"username": self.username},
            )
            return []

        try:
            response = self.rest.get(
                "/api/account/metric/nav",
                params={"accountID": self.ID},
            )
            if isinstance(response, list):
                self.logger.info(
                    "event=nav_history_resolved",
                    extra={"accountID": self.ID, "points": len(response)},
                )
                return response
            self.logger.warning(
                "event=nav_invalid_format",
                extra={"accountID": self.ID, "response": str(response)},
            )
            return []
        except Exception as e:
            self.logger.error(
                "event=nav_fetch_failed",
                extra={"accountID": self.ID, "error": str(e)},
            )
            return []

    def get_max_drawdown(self) -> Dict[str, Any]:
        """Fetch Max Drawdown (MDD) statistics."""
        if not self._ensure_account_id():
            self.logger.warning(
                "event=mdd_skipped_due_to_missing_id",
                extra={"username": self.username},
            )
            return {}

        try:
            response = self.rest.get(
                "/api/account/metric/mdd",
                params={"accountID": self.ID},
            )
            if isinstance(response, dict) and "maxDrawdownPct" in response:
                self.logger.info(
                    "event=mdd_resolved",
                    extra={
                        "accountID": response.get("accountID", self.ID),
                        "maxDrawdownPct": response["maxDrawdownPct"],
                    },
                )
                return {
                    "accountID": response.get("accountID", self.ID),
                    "maxDrawdownPct": response["maxDrawdownPct"],
                }
            self.logger.warning(
                "event=mdd_invalid_format",
                extra={"accountID": self.ID, "response": str(response)},
            )
            return {}
        except Exception as e:
            self.logger.error(
                "event=mdd_fetch_failed",
                extra={"accountID": self.ID, "error": str(e)},
            )
            return {}

    def get_drawdown_periods(self) -> List[Dict[str, Any]]:
        """Fetch all drawdown periods for current account."""
        if not self._ensure_account_id():
            self.logger.warning(
                "event=drawdown_periods_skipped_due_to_missing_id",
                extra={"username": self.username},
            )
            return []

        try:
            response = self.rest.get(
                "/api/account/metric/drawdowns",
                params={"accountID": self.ID},
            )
            if isinstance(response, list):
                self.logger.info(
                    "event=drawdown_periods_resolved",
                    extra={"accountID": self.ID, "count": len(response)},
                )
                return response
            self.logger.warning(
                "event=drawdown_periods_invalid_format",
                extra={"accountID": self.ID, "response": str(response)},
            )
            return []
        except Exception as e:
            self.logger.error(
                "event=drawdown_periods_fetch_failed",
                extra={"accountID": self.ID, "error": str(e)},
            )
            return []
