"""Deprecation shim — renamed to paperbroker.rest.session in v0.2.5."""
import warnings

warnings.warn(
    "paperbroker.rest.rest_session is deprecated; use paperbroker.rest.session "
    "(renamed in v0.2.5). This shim will be removed in v0.3.0.",
    DeprecationWarning,
    stacklevel=2,
)

from paperbroker.rest.session import RestSession  # noqa: F401,E402

__all__ = ["RestSession"]
