"""
REST subpackage — account + session.

v0.2.5 split account_client.py into account.py + metrics.py + transactions.py.
Old imports continue to work via deprecation shims at the original paths
(rest_session.py, account_client.py).
"""
from .account import AccountClient
from .metrics import AccountMetricsMixin
from .session import RestSession
from .transactions import AccountTransactionsMixin

__all__ = [
    "AccountClient",
    "AccountMetricsMixin",
    "AccountTransactionsMixin",
    "RestSession",
]
