"""
REST AccountClient — core methods (auth, balance, orders, portfolio, max-placeable).

In v0.2.5 the 1338L paperbroker.rest.account_client module was split by
cohesion into three files:

    - account.py       (this file, ~600L) — auth, account ID, balance,
                                              orders, portfolio, max-placeable
    - metrics.py       (~200L)             — executions, NAV, drawdown
    - transactions.py  (~140L)             — transaction history

AccountClient inherits the metrics + transactions mixins so the public
surface is unchanged. Old `paperbroker.rest.account_client.AccountClient`
import is preserved via a shim.
"""
import re
from typing import Any, Dict, List, Optional

from paperbroker.logger import get_logger
from paperbroker.sub_account import SubAccountProvider
from .metrics import AccountMetricsMixin
from .session import RestSession
from .transactions import AccountTransactionsMixin


class AccountClient(AccountTransactionsMixin, AccountMetricsMixin):
    """
    High-level REST client for trading account operations.

    Composes auth + balance + orders + portfolio (here) with metrics +
    transactions (mixins). Public method list and signatures are
    identical to the pre-v0.2.5 monolithic class.
    """

    def __init__(
        self,
        rest_session: RestSession,
        sub_provider: SubAccountProvider,
        username: str,
        password: str,
        log_dir: str = "logs",
        console: bool = False,
        log_propagate: bool = False,
    ):
        self.rest = rest_session
        self.sub = sub_provider
        self.username = username
        self.password = password
        self.logger = get_logger(log_dir, console, propagate=log_propagate)
        self.ID: Optional[str] = None

    def _fetch_account_id(self) -> Optional[str]:
        try:
            resp = self.rest.post(
                "/api/fix-account-info/get-fix-id",
                json={"username": self.username, "password": self.password},
            )
            if isinstance(resp, dict):
                fix_id = resp.get("fixAccountID") or resp.get("accountID")
                if (resp.get("success", fix_id is not None)) and fix_id:
                    self.logger.info(
                        "event=fix_id_resolved",
                        extra={
                            "username": self.username,
                            "fixAccountID": fix_id,
                        },
                    )
                    return fix_id
                if resp.get("message") or resp.get("error"):
                    self.logger.warning(
                        "event=fix_id_auth_failed",
                        extra={
                            "username": self.username,
                            "message": resp.get("message") or resp.get("error"),
                        },
                    )
                    return None
                self.logger.warning(
                    "event=fix_id_fetch_invalid",
                    extra={
                        "username": self.username,
                        "response": str(resp),
                    },
                )
            else:
                self.logger.warning(
                    "event=fix_id_fetch_unexpected_type",
                    extra={
                        "username": self.username,
                        "response_type": type(resp).__name__,
                    },
                )
        except Exception as e:
            self.logger.error(
                "event=fix_id_fetch_failed",
                extra={
                    "username": self.username,
                    "error": str(e),
                    "endpoint": "/api/fix-account-info/get-fix-id",
                },
            )
        return None

    def _ensure_account_id(self) -> bool:
        if self.ID is None:
            self.ID = self._fetch_account_id()
        return self.ID is not None

    def resolve_on_connect(self) -> Optional[str]:
        if not self._ensure_account_id():
            self.logger.warning(
                "event=account_id_not_resolved_on_connect",
                extra={"username": self.username},
            )
        return self.ID

    # ---- Balance ----
    def get_remain_balance(self) -> Dict[str, Any]:
        if not self._ensure_account_id():
            self.logger.warning(
                "event=remain_cash_missing_fix_id",
                extra={"username": self.username},
            )
            return {}
        sub_id = self.sub.current()
        if not sub_id:
            self.logger.warning(
                "event=remain_cash_missing_sub_id",
                extra={"fixAccountID": self.ID},
            )
            return {}
        try:
            resp = self.rest.post(
                "/api/account-info-by-sub/remain-cash",
                json={"fixAccountID": self.ID, "subAccountID": sub_id},
            )
            if isinstance(resp, dict):
                amount = (
                    resp.get("remainCash")
                    or resp.get("remain")
                    or resp.get("remainBalance")
                )
                if (resp.get("success", amount is not None)) and amount is not None:
                    self.logger.info(
                        "event=remain_cash_resolved",
                        extra={
                            "fixAccountID": self.ID,
                            "subAccountID": sub_id,
                            "remainCash": str(amount),
                        },
                    )
                    return {
                        "fixAccountID": self.ID,
                        "subAccountID": sub_id,
                        "remainCash": amount,
                    }
                if resp.get("message") or resp.get("error"):
                    self.logger.warning(
                        "event=remain_cash_failed",
                        extra={
                            "fixAccountID": self.ID,
                            "subAccountID": sub_id,
                            "message": resp.get("message") or resp.get("error"),
                        },
                    )
                    return {}
                self.logger.warning(
                    "event=remain_cash_invalid_format",
                    extra={
                        "fixAccountID": self.ID,
                        "subAccountID": sub_id,
                        "response": str(resp),
                    },
                )
            else:
                self.logger.warning(
                    "event=remain_cash_unexpected_type",
                    extra={
                        "fixAccountID": self.ID,
                        "subAccountID": sub_id,
                        "response_type": type(resp).__name__,
                    },
                )
        except Exception as e:
            self.logger.error(
                "event=remain_cash_fetch_failed",
                extra={
                    "fixAccountID": self.ID,
                    "subAccountID": sub_id,
                    "error": str(e),
                },
            )
        return {}

    def get_total_balance(self) -> Dict[str, Any]:
        if not self._ensure_account_id():
            self.logger.warning(
                "event=total_balance_missing_fix_id",
                extra={"username": self.username},
            )
            return {}

        sub_id = self.sub.current()
        if not sub_id:
            self.logger.warning(
                "event=total_balance_missing_sub_id",
                extra={"fixAccountID": self.ID},
            )
            return {}

        try:
            resp = self.rest.post(
                "/api/account-info-by-sub/total-balance",
                json={"fixAccountID": self.ID, "subAccountID": sub_id},
            )

            if isinstance(resp, dict):
                amount = (
                    resp.get("totalBalance") or resp.get("total") or resp.get("balance")
                )
                if (resp.get("success", amount is not None)) and amount is not None:
                    self.logger.info(
                        "event=total_balance_resolved",
                        extra={
                            "fixAccountID": self.ID,
                            "subAccountID": sub_id,
                            "totalBalance": str(amount),
                        },
                    )
                    return {
                        "fixAccountID": self.ID,
                        "subAccountID": sub_id,
                        "totalBalance": amount,
                    }

                if resp.get("message") or resp.get("error"):
                    self.logger.warning(
                        "event=total_balance_failed",
                        extra={
                            "fixAccountID": self.ID,
                            "subAccountID": sub_id,
                            "message": resp.get("message") or resp.get("error"),
                        },
                    )
                    return {}

                self.logger.warning(
                    "event=total_balance_invalid_format",
                    extra={
                        "fixAccountID": self.ID,
                        "subAccountID": sub_id,
                        "response": str(resp),
                    },
                )
            else:
                self.logger.warning(
                    "event=total_balance_unexpected_type",
                    extra={
                        "fixAccountID": self.ID,
                        "subAccountID": sub_id,
                        "response_type": type(resp).__name__,
                    },
                )
        except Exception as e:
            self.logger.error(
                "event=total_balance_fetch_failed",
                extra={
                    "fixAccountID": self.ID,
                    "subAccountID": sub_id,
                    "error": str(e),
                },
            )
        return {}

    # ---- Orders ----
    def get_stock_orders(self) -> List[Dict[str, Any]]:
        if not self._ensure_account_id():
            self.logger.warning(
                "event=stock_orders_skipped_due_to_missing_id",
                extra={"username": self.username},
            )
            return []
        try:
            response = self.rest.get(
                "/api/account/orders/stock",
                params={"accountID": self.ID},
            )
            if isinstance(response, list):
                self.logger.info(
                    "event=stock_orders_resolved",
                    extra={"accountID": self.ID, "count": len(response)},
                )
                return response
            self.logger.warning(
                "event=stock_orders_invalid_format",
                extra={"accountID": self.ID, "response": str(response)},
            )
            return []
        except Exception as e:
            self.logger.error(
                "event=stock_orders_fetch_failed",
                extra={"accountID": self.ID, "error": str(e)},
            )
            return []

    def get_derivative_orders(self) -> List[Dict[str, Any]]:
        if not self._ensure_account_id():
            self.logger.warning(
                "event=derivative_orders_skipped_due_to_missing_id",
                extra={"username": self.username},
            )
            return []
        try:
            response = self.rest.get(
                "/api/account/orders/derivative",
                params={"accountID": self.ID},
            )
            if isinstance(response, list):
                self.logger.info(
                    "event=derivative_orders_resolved",
                    extra={"accountID": self.ID, "count": len(response)},
                )
                return response
            self.logger.warning(
                "event=derivative_orders_invalid_format",
                extra={"accountID": self.ID, "response": str(response)},
            )
            return []
        except Exception as e:
            self.logger.error(
                "event=derivative_orders_fetch_failed",
                extra={"accountID": self.ID, "error": str(e)},
            )
            return []

    def get_orders(
        self,
        start_date: str,
        end_date: str,
    ) -> Dict[str, Any]:
        """Fetch orders for current sub-account within date range."""
        if not self._ensure_account_id():
            self.logger.warning(
                "event=orders_missing_fix_id",
                extra={"username": self.username},
            )
            return {}

        sub_id = self.sub.current()
        if not sub_id:
            self.logger.warning(
                "event=orders_missing_sub_id",
                extra={"fixAccountID": self.ID},
            )
            return {}

        date_pattern = r"^\d{4}-\d{2}-\d{2}$"
        if not re.match(date_pattern, start_date) or not re.match(date_pattern, end_date):
            self.logger.warning(
                "event=orders_invalid_date_format",
                extra={
                    "fixAccountID": self.ID,
                    "subAccountID": sub_id,
                    "start_date": start_date,
                    "end_date": end_date,
                },
            )
            return {}

        try:
            resp = self.rest.post(
                "/api/portfolio-by-sub/orders",
                json={
                    "fixAccountID": self.ID,
                    "subAccountID": sub_id,
                    "startTime": start_date,
                    "endTime": end_date,
                },
            )

            if isinstance(resp, dict):
                if resp.get("success") and "items" in resp:
                    items = resp.get("items", [])
                    self.logger.info(
                        "event=orders_resolved",
                        extra={
                            "fixAccountID": self.ID,
                            "subAccountID": sub_id,
                            "start_date": start_date,
                            "end_date": end_date,
                            "order_count": len(items),
                        },
                    )
                    return resp

                if resp.get("error"):
                    self.logger.warning(
                        "event=orders_failed",
                        extra={
                            "fixAccountID": self.ID,
                            "subAccountID": sub_id,
                            "start_date": start_date,
                            "end_date": end_date,
                            "error": resp.get("error"),
                        },
                    )
                    return {}

                self.logger.warning(
                    "event=orders_invalid_format",
                    extra={
                        "fixAccountID": self.ID,
                        "subAccountID": sub_id,
                        "response": str(resp),
                    },
                )
            else:
                self.logger.warning(
                    "event=orders_unexpected_type",
                    extra={
                        "fixAccountID": self.ID,
                        "subAccountID": sub_id,
                        "response_type": type(resp).__name__,
                    },
                )
        except Exception as e:
            self.logger.error(
                "event=orders_fetch_failed",
                extra={
                    "fixAccountID": self.ID,
                    "subAccountID": sub_id,
                    "start_date": start_date,
                    "end_date": end_date,
                    "error": str(e),
                },
            )

        return {}

    # ---- Portfolio ----
    def get_portfolio(self) -> Dict[str, Any]:
        if not self._ensure_account_id():
            self.logger.warning(
                "event=portfolio_skipped_due_to_missing_id",
                extra={"username": self.username},
            )
            return {}

        try:
            response = self.rest.get(
                "/api/account/portfolio",
                params={"accountID": self.ID},
            )
            if isinstance(response, dict) and "holdings" in response:
                self.logger.info(
                    "event=portfolio_resolved",
                    extra={
                        "accountID": response.get("accountID", self.ID),
                        "holdings_count": len(response.get("holdings", [])),
                    },
                )
                return response
            self.logger.warning(
                "event=portfolio_invalid_format",
                extra={"accountID": self.ID, "response": str(response)},
            )
            return {}
        except Exception as e:
            self.logger.error(
                "event=portfolio_fetch_failed",
                extra={"accountID": self.ID, "error": str(e)},
            )
            return {}

    def get_portfolio_by_sub(self) -> Dict[str, Any]:
        """Fetch portfolio positions for current sub-account."""
        if not self._ensure_account_id():
            self.logger.warning(
                "event=portfolio_missing_fix_id",
                extra={"username": self.username},
            )
            return {}

        sub_id = self.sub.current()
        if not sub_id:
            self.logger.warning(
                "event=portfolio_missing_sub_id",
                extra={"fixAccountID": self.ID},
            )
            return {}

        try:
            resp = self.rest.post(
                "/api/portfolio-by-sub/basic",
                json={
                    "fixAccountID": self.ID,
                    "subAccountID": sub_id,
                },
            )

            if isinstance(resp, dict):
                if resp.get("success") and "items" in resp:
                    items = resp.get("items", [])
                    self.logger.info(
                        "event=portfolio_resolved",
                        extra={
                            "fixAccountID": self.ID,
                            "subAccountID": sub_id,
                            "instrument_count": len(items),
                        },
                    )
                    return resp

                if resp.get("error"):
                    self.logger.warning(
                        "event=portfolio_failed",
                        extra={
                            "fixAccountID": self.ID,
                            "subAccountID": sub_id,
                            "error": resp.get("error"),
                        },
                    )
                    return {}

                self.logger.warning(
                    "event=portfolio_invalid_format",
                    extra={
                        "fixAccountID": self.ID,
                        "subAccountID": sub_id,
                        "response": str(resp),
                    },
                )
            else:
                self.logger.warning(
                    "event=portfolio_unexpected_type",
                    extra={
                        "fixAccountID": self.ID,
                        "subAccountID": sub_id,
                        "response_type": type(resp).__name__,
                    },
                )
        except Exception as e:
            self.logger.error(
                "event=portfolio_fetch_failed",
                extra={
                    "fixAccountID": self.ID,
                    "subAccountID": sub_id,
                    "error": str(e),
                },
            )

        return {}

    # ---- Max placeable ----
    def get_max_placeable(
        self,
        symbol: str,
        price: float,
        side: str,
    ) -> Dict[str, Any]:
        """Calculate maximum placeable quantity for an order."""
        if not self._ensure_account_id():
            self.logger.warning(
                "event=max_placeable_skipped_due_to_missing_account_id",
                extra={"username": self.username},
            )
            return {}

        current_sub = self.sub.current()

        try:
            payload = {
                "fixAccountID": self.ID,
                "subAccountID": current_sub,
                "symbol": symbol,
                "price": price,
                "side": side.upper(),
            }

            self.logger.debug(
                "event=max_placeable_request",
                extra={
                    "fixAccountID": self.ID,
                    "subAccountID": current_sub,
                    "symbol": symbol,
                    "price": price,
                    "side": side,
                },
            )

            response = self.rest.post(
                "/api/max-placeable-by-sub/max-placeable",
                json=payload,
            )

            if isinstance(response, dict):
                success = response.get("success", False)
                max_qty = response.get("maxQty")
                per_unit_cost = response.get("perUnitCost")
                remain_cash = response.get("remainCash")
                unlimited = response.get("unlimited", False)

                self.logger.info(
                    "event=max_placeable_resolved",
                    extra={
                        "fixAccountID": self.ID,
                        "subAccountID": current_sub,
                        "symbol": symbol,
                        "maxQty": max_qty,
                        "success": success,
                    },
                )

                return {
                    "success": success,
                    "maxQty": max_qty,
                    "perUnitCost": per_unit_cost,
                    "remainCash": remain_cash,
                    "unlimited": unlimited,
                }
            self.logger.warning(
                "event=max_placeable_invalid_format",
                extra={
                    "fixAccountID": self.ID,
                    "subAccountID": current_sub,
                    "response": str(response),
                },
            )
            return {}
        except Exception as e:
            self.logger.error(
                "event=max_placeable_fetch_failed",
                extra={
                    "fixAccountID": self.ID,
                    "subAccountID": current_sub,
                    "symbol": symbol,
                    "error": str(e),
                },
            )
            return {}
