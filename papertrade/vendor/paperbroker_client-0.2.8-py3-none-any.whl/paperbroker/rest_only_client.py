"""
Deprecation shim — ``PaperBrokerRESTClient`` is now ``PaperBrokerClient(enable_fix=False)``.

Pre-v0.2.5 this module shipped a separate facade for Mac/arm64 environments
without QuickFIX. v0.2.5 merged it into the unified ``PaperBrokerClient`` via
``enable_fix=False``. The class name remains importable for back-compat.

Notes on the merge:
    - REST endpoints now route through ``AccountClient`` (same as full mode),
      which is the canonical implementation. The original rest-only facade
      used a different (less complete) endpoint path.
    - ``connect()`` returns ``bool`` here to preserve the original signature
      (the unified facade returns ``None``).
"""
import warnings
from typing import Any, Dict, Optional

from paperbroker.client import PaperBrokerClient


class PaperBrokerRESTClient(PaperBrokerClient):
    """
    REST-only client — backward-compatible shim.

    Functionally equivalent to ``PaperBrokerClient(enable_fix=False)``;
    overrides ``connect()`` to return bool.
    """

    def __init__(
        self,
        rest_base_url: str,
        username: str,
        password: str,
        default_sub_account: Optional[str] = None,
        log_dir: str = "logs",
        console: bool = False,
    ):
        warnings.warn(
            "PaperBrokerRESTClient is deprecated; use "
            "PaperBrokerClient(enable_fix=False) instead. "
            "This shim will be removed in v0.3.0.",
            DeprecationWarning,
            stacklevel=2,
        )
        super().__init__(
            default_sub_account=default_sub_account or "",
            username=username,
            password=password,
            rest_base_url=rest_base_url,
            log_dir=log_dir,
            console=console,
            enable_fix=False,
            order_store_path=None,
        )

    def connect(self) -> bool:  # type: ignore[override]
        """REST-only connect — returns True on success, False otherwise."""
        try:
            account_id = self.accounting.resolve_on_connect()
            return account_id is not None
        except Exception:
            return False

    def is_connected(self) -> bool:
        return self.accounting.ID is not None

    @property
    def account_id(self) -> Optional[str]:
        return self.accounting.ID


# Convenience alias preserved from the original module.
RESTClient = PaperBrokerRESTClient
